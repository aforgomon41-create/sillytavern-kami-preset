import { compile } from '../schema.js';
import { SolveCore } from '../engine.js';
import { createArchive, headKey, restore, replay } from '../history.js';
import { SolveRuntime } from '../runtime.js';
import { PerformanceTrace, measure } from '../performance.js';
import { VerifiedHistory } from '../verified-history.js';
import { IndexedDbCache } from '../cache.js';
import { assertJson, canonical, clone, fail, hash, id } from '../json.js';
import { extractRawBlocks, hideBlocks, parseOperations, promptText, stripBlocks } from '../parser.js';
import { guide, registerMacros, sop, toJson, toToon } from '../projection.js';
import { archiveFromChat, browserWriteLock, preserveOrphanAncestors, SillyTavern119Adapter } from './sillytavern.js';
import { DiagnosticJournal, describeError, inspectCapabilities } from '../diagnostics.js';
import { EntityGraph } from '../entities.js';
import { at } from '../json.js';
import { project } from '../projection.js';
import { schemaText } from '../schema-text.js';
import type { ProjectionOptions } from '../projection.js';
import jsonpatch from 'fast-json-patch';
import { isModuleEnabled } from '../schema.js';
import { activeVariableView, writeMessageVariableViews } from './variables.js';
import { readToken } from './storage-tokens.js';
import { reconcileSwipeDeletion } from './storage-pointers.js';
import { verifyDefinitionSnapshot } from '../definition-snapshot.js';
import { adoptArchive, checkAdopted, verifyAdoption } from '../adopt.js';
import type { HostContext } from './sillytavern.js';
import type { Action, Batch, Commit, Definition, Json, SettingsPatch } from '../types.js';
import { computeAll, listLimit, nextRound } from '../features.js';
import { UPDATE_PREFS } from './inject.js';
import { operatorRequest as prefsRequest, readOperatorPrefs, type OperatorPrefs } from './operator.js';

export interface AttachOptions {
  mode?: 'in-band' | 'out-of-band';
  operatorFormat?: 'json' | 'toon';
  operatorProfileId?: string;
  operatorRequest?: (prompt: string, signal: AbortSignal) => Promise<string>;
  operatorTimeoutMs?: number;
  allowRequestsDuringOperatorBusy?: boolean;
  /** The chat was started under another version of this definition: take it over if every commit replays identically (src/adopt.ts). */
  adopt?: boolean;
  cache?: IndexedDbCache | false;
  onError?: (error: unknown) => void;
}
/** The operations in an operator model's answer: its <solve_operate> block, or the bare JSON (code fences allowed). */
export function parseOperatorOutput(output: string): Batch {
  const raw = extractRawBlocks(output).model ?? output;
  return parseOperations(raw.trim().replace(/^```[a-z]*\s*/iu, '').replace(/\s*```\s*$/u, ''));
}
const HIDE_KEY = Symbol.for('solve.hide-operation-blocks');
/**
 * One display hook per page (the tavern's formatter has no way to remove a hook): it hides operation blocks while any
 * SOLVE part that asked for it is alive. The set of askers lives on the formatter, so a reloaded SOLVE reuses the hook.
 */
export function hideOperationBlocks(formatter: { addHook(fn: (text: string) => string, options?: { stage?: string; order?: number }): void }, alive: () => boolean): () => void {
  const holder = formatter as unknown as Record<symbol, Set<() => boolean> | undefined>;
  let askers = holder[HIDE_KEY];
  if (!askers) {
    askers = holder[HIDE_KEY] = new Set();
    const set = askers;
    formatter.addHook((text: string) => {
      let on = false;
      for (const ask of set) { try { if (ask()) { on = true; break; } } catch { /* a stale asker counts as gone */ } }
      return on && typeof text === 'string' ? hideBlocks(text) : text;
    }, { stage: 'beforeRegex', order: 5 });
  }
  askers.add(alive);
  return () => { askers!.delete(alive); };
}
export class SillyTavernController {
  readonly adapter: SillyTavern119Adapter;
  runtime!: SolveRuntime;
  private disposers: (() => void)[] = [];
  private readyState = false;
  private operator?: AbortController;
  private processing: Promise<unknown> = Promise.resolve();
  private queued = 0;
  private chatId: string;
  private generated = false;
  private generationEpoch = 0;
  private generationRendered?: Promise<void>;
  private releaseGeneration?: () => void;
  private finalizingGeneration = false;
  private disposed = false;
  private reason = '正在初始化';
  private hostVersion?: string;
  private cache?: IndexedDbCache;
  private ownsCache = false;
  private cacheError?: string;
  private pendingImportError?: string;
  private nativeHistoryChanged = false;
  private listeners = new Set<() => void>();
  readonly journal = new DiagnosticJournal();
  readonly performance = new PerformanceTrace();
  private history = new VerifiedHistory({}, this.performance);
  getPerformance() { return this.performance.read(); }
  getVerificationStats() { return this.history.getStats(); }
  clearPerformance(): void { this.performance.clear(); }
  constructor(public readonly core: SolveCore, private context: () => HostContext, public readonly options: AttachOptions = {}, fetcher: typeof fetch = fetch) {
    this.chatId = context().chatId;
    this.adapter = new SillyTavern119Adapter(context, fetcher, browserWriteLock, this.performance, this.history);
    this.adapter.onNotice = (code, message) => this.record(code, message, 'warning');
    if (options.cache) this.cache = options.cache;
    else if (options.cache !== false && typeof indexedDB !== 'undefined') { this.cache = new IndexedDbCache(); this.ownsCache = true; }
  }
  get busy(): boolean { return this.finalizingGeneration || this.queued > 0 || Boolean(this.operator) || Boolean(this.runtime?.busy); }
  get boundChatId(): string { return this.chatId; }
  get ready(): boolean {
    if (!this.readyState || this.disposed) return false;
    // The host replaces chat data before its CHAT_CHANGED signal. Formatting
    // may probe the previous scoped controller during that interval.
    try { return this.context().chatId === this.chatId; } catch { return false; }
  }
  assertReady(): void { if (!this.ready) fail('STATE_NOT_READY', `当前聊天尚未绑定并恢复SOLVE状态${this.reason ? `：${this.reason}` : ''}`); }
  private assertBound(): void { if (this.disposed || this.context().chatId !== this.chatId) fail('STALE_BINDING', '控制器已释放或聊天已经切换'); }
  subscribe(listener: () => void): () => void { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; }
  private notify(): void {
    this.updateVariableSnapshot();
    for (const listener of this.listeners) { try { listener(); } catch { /* A debug view cannot break a commit. */ } }
  }
  private updateVariableSnapshot(): void {
    if (!this.runtime) return;
    try {
      const ctx = this.context(); if (ctx.chatId !== this.chatId) return;
      const status = this.getStatus(), commit = this.runtime.getCommit();
      if (!commit) return;
      const ready = status.ready && !status.pendingCount && !this.disposed;
      const reason = status.pendingCount ? '有待保存操作，显示已确认的历史状态' : status.reason;
      const view = activeVariableView(commit, this.runtime.getState(), ready, reason);
      ctx.chatMetadata.variables = { ...ctx.chatMetadata.variables, solve: view };
    } catch { /* Stale/disposed contexts must not touch the next chat. */ }
  }
  private async syncVariableViews(): Promise<void> {
    this.assertBound();
    this.updateVariableSnapshot();
    if (this.ready && !this.runtime.pendingCount && !this.pendingImportError && !this.nativeHistoryChanged) {
      try { await this.adapter.syncVariables(this.runtime.archive, this.runtime.headId); }
      // Writing back an already archived history adds nothing new: a failure (network…) leaves the disk behind, not the state wrong.
      // Stay usable; the next save writes the same views again.
      catch (error) {
        // A conflict with what is on disk (another tab, a foreign record) still stops; a failed request does not.
        const code = describeError(error).code;
        if (['REMOTE_HEAD_CHANGED', 'ARCHIVE_OWNERSHIP', 'STATE_NOT_ALIGNED', 'DEFINITION_SNAPSHOT_CHANGED', 'STORAGE_MISSING', 'STORAGE_HEAD_MISMATCH'].includes(code)) {
          this.readyState = false; this.reason = describeError(error).message;
        } else this.record('VARIABLES_SYNC_FAILED', `写回变量快照失败：${describeError(error).message}`, 'warning');
        throw error;
      }
      this.assertBound(); this.updateVariableSnapshot();
    }
  }
  async guardNativeSave(body: unknown, send: () => Promise<Response>): Promise<Response> {
    try { this.assertBound(); return await this.adapter.guardNativeSave(body, send); }
    catch (error) { this.markDirty(describeError(error).message); this.report(error); throw error; }
  }
  private record(code: string, message: string, level: 'info' | 'warning' | 'error' = 'info', durationMs?: number): void { this.journal.add(level, code, message, durationMs); this.notify(); }
  private report(error: unknown): void {
    const e = describeError(error); this.record(e.code, e.message, 'error');
    try { this.options.onError?.(error); } catch { /* observer only */ }
  }
  private restoreState: typeof restore = (archive, commitId) => this.cache ? this.cache.restore(archive, commitId, this.history) : VerifiedHistory.recover(this.history, archive, commitId);
  private createRuntime(archive: import('../types.js').Archive, head: string): SolveRuntime {
    return new SolveRuntime(this.core, archive, head, this.adapter, this.restoreState, {
      onError: error => { this.record('FACET_HOOK_FAILED', error instanceof Error ? error.message : String(error), 'warning'); },
      submit: (operations, parent, chain, actionId) => {
        this.assertBound(); this.adapter.assertCurrent(parent.binding);
        const index = this.context().chat.findIndex(message => message.extra?.solve?.messageId === parent.binding.messageId);
        if (index < 0) fail('STALE_BINDING', 'Hook原消息已经不存在');
        return this.submit(operations, { actionId, index, expectedHead: parent.id, authorInputs: { solveFacetChain: chain } });
      },
    }, this.performance, this.history);
  }
  private async useCache(task: (cache: IndexedDbCache) => Promise<unknown>): Promise<void> {
    if (!this.cache) return;
    try { await task(this.cache); this.cacheError = undefined; }
    catch (error) { this.cacheError = describeError(error).message; this.record('CACHE_UNAVAILABLE', this.cacheError, 'warning'); }
    finally { if (this.disposed && this.ownsCache) this.cache.close(); }
  }
  async start(): Promise<this> {
    this.assertBound(); this.hostVersion = await this.adapter.verifyVersion(); this.assertBound();
    const ctx = this.context();
    const index = ctx.chat.findIndex(m => !m.is_user && !m.is_system);
    if (index < 0) fail('NO_GREETING', '请先建立一条角色开场消息');
    const initialBinding = this.adapter.binding(index);
    let archive = await this.adapter.load();
    this.assertBound();
    let head: string;
    if (!archive) {
      const created = await createArchive(this.core, initialBinding);
      archive = created.archive; head = created.headId;
      const root = archive.commits[head]!; root.textDigest = await hash(ctx.chat[index]!.mes);
      await this.adapter.save({ archive, commit: root, binding: initialBinding, text: ctx.chat[index]!.mes, expectedHead: null });
    } else {
      if (archive.definitionHash !== this.core.definition.fingerprint) {
        if (!this.options.adopt) fail('DEFINITION_MISMATCH', '此聊天使用不同版本的作者定义');
        archive = await this.adopt(archive, index, initialBinding);
      }
      if (archive.authoring) await verifyDefinitionSnapshot(archive.authoring, archive.definitionHash);
      try { head = this.findParent(ctx.chat.length, archive); }
      catch (error) {
        if (!['HISTORY_BRANCH_CONFLICT', 'GENESIS_SELECTION'].includes(describeError(error).code)) throw error;
        head = ctx.chat.map(m => m.extra?.solve?.headId).filter((id: string) => archive!.commits[id]).at(-1)
          ?? Object.values(archive.commits).find(c => c.parentId === null)?.id;
        if (!head) throw error;
        this.reason = describeError(error).message;
      }
    }
    this.runtime = this.createRuntime(archive, head);
    await this.runtime.ready(); this.assertBound();
    if (this.reason === '正在初始化') this.reason = '';
    for (const message of ctx.chat) {
      const commit = archive.commits[message.extra?.solve?.headId];
      if (commit && commit.textDigest !== await hash(message.mes)) { this.reason = '消息正文与归档不一致，请重放变更楼层及后续历史'; break; }
    }
    this.readyState = !this.reason;
    if (this.cache) {
      let drafts: import('../types.js').SaveDraft[] | undefined;
      await this.useCache(async cache => { drafts = await cache.loadPending(archive!.sessionId); });
      if (drafts && !Array.isArray(drafts)) { this.pendingImportError = '本地草稿格式无效，可在调试面板中放弃'; this.record('PENDING_INVALID', this.pendingImportError, 'warning'); }
      if (Array.isArray(drafts) && drafts.length) {
        // A lost response can leave a draft which is already part of the confirmed archive.
        const pending = drafts.filter(d => !archive!.commits[d.commit.id]);
        if (pending.length) {
          try { this.runtime.importPending(pending); }
          catch (error) { this.pendingImportError = describeError(error).message; this.record('PENDING_CONFLICT', `本地草稿无法导入：${this.pendingImportError}`, 'warning'); }
        }
      }
    }
    if (ctx.macros?.registry) this.disposers.push(registerMacros(ctx.macros.registry, () => {
      this.assertReady();
      if (this.findParent(this.context().chat.length) !== this.runtime.headId) fail('STATE_NOT_ALIGNED', '模型输入尚未对齐当前选中的历史');
      return { definition: this.core.definition, state: this.runtime.getState(), feedback: this.runtime.getCommit()!.feedback };
    }, () => this.mode() === 'out-of-band'));
    await this.syncVariableViews();
    this.installEvents();
    for (const capability of inspectCapabilities(ctx, this.hostVersion).filter(c => !c.available)) this.record('CAPABILITY_MISSING', `${capability.label}：${capability.detail}`, 'warning');
    this.record(this.readyState ? 'READY' : 'HISTORY_DIRTY', this.readyState ? '当前聊天状态已恢复' : this.reason, this.readyState ? 'info' : 'warning');
    if (this.readyState) this.catchUp();
    return this;
  }
  /**
   * Take over a chat started under another version of the definition (an older official structure, or before
   * prompt text left the fingerprint). Every commit on every branch is re-executed with the current definition;
   * only identical results let the chat move over. The history itself is not changed, only the definition it is recorded under.
   */
  private async adopt(archive: import('../types.js').Archive, greeting: number, binding: import('../types.js').Binding): Promise<import('../types.js').Archive> {
    const chat = this.context().chat;
    const floor = new Map<string, number>();
    chat.forEach((m, i) => { const id = m.extra?.solve?.messageId; if (id && !floor.has(id)) floor.set(id, i); });
    const { commits } = await verifyAdoption(this.core, archive, c => floor.has(c.binding.messageId) ? `第 ${floor.get(c.binding.messageId)} 楼` : '一条已不在聊天里的历史');
    this.assertBound();
    const next = adoptArchive(archive, this.core.definition.fingerprint);
    const head = next.heads[headKey(binding)];
    const commit = head ? next.commits[head] : undefined;
    if (!commit) fail('DEFINITION_MISMATCH', '找不到开场白的变量记录，不能换用当前结构');
    const text = chat[greeting]!.mes;
    if (await hash(text) !== commit.textDigest) fail('DEFINITION_MISMATCH', '开场白改过，和变量记录对不上，不能换用当前结构');
    await checkAdopted(next, head!);
    await this.adapter.save({ archive: next, commit, binding, text, expectedHead: head! });
    this.assertBound();
    const loaded = await this.adapter.load();
    if (!loaded || loaded.definitionHash !== this.core.definition.fingerprint) fail('SAVE_VERIFY_FAILED', '换用当前结构后回读的聊天不对');
    const def = this.core.definition;
    this.record('ADOPTED', `这个聊天由另一版结构开局，已换用 ${def.id}@${def.version} 继续：${commits} 条变量记录在当前结构下逐条重算，结果与存档一致`, 'info');
    try { (globalThis as any).toastr?.info(`这个聊天是用旧版结构开的，已换用当前版本继续。${commits} 条变量记录逐条重算过，结果完全一致。`, 'SOLVE', { timeOut: 8000 }); } catch { /* no toasts */ }
    return loaded;
  }
  /** The latest reply carries a complete operation block that was never processed (e.g. SOLVE was off or failed then). */
  private unprocessedReply(): number | undefined {
    const chat = this.context().chat;
    for (let i = chat.length - 1; i > 0; i--) {
      const m = chat[i]!;
      if (m.is_user || m.is_system) continue;
      return !m.extra?.solve?.headId && /<solve_operate>[\s\S]*?<\/solve_operate>/u.test(m.mes ?? '') ? i : undefined;
    }
    return undefined;
  }
  /** On opening a chat: process a latest reply whose operations never were. */
  private catchUp(): void {
    const index = this.unprocessedReply();
    if (index === undefined) return;
    this.record('CATCH_UP', `楼层 ${index} 的回复带有变量操作但还没处理过，现在补上`);
    void this.processMessage(index).then(commit => {
      if (commit) this.record('CATCH_UP', `楼层 ${index} 的变量操作已补处理`);
    }, error => {
      // Overtaken by a generation or a chat switch: nothing went wrong, the next turn sees it again.
      if (['STALE_BINDING', 'STALE_ACTION', 'STATE_NOT_ALIGNED'].includes(describeError(error).code)) { this.record('CATCH_UP', `楼层 ${index} 的补处理被新的生成打断，稍后再补`); return; }
      void this.retrySilently(error).then(ok => { if (!ok) this.tellUnprocessed(index, describeError(error).message); });
    });
  }
  private tellUnprocessed(index: number, why: string): void {
    this.record('REPLY_UNPROCESSED', `楼层 ${index} 回复里的变量操作没有处理：${why}`, 'warning');
    const fix = this.runtime.pendingCount ? '可以点输入框上方的「重试保存」' : '可以点输入框上方的「重新处理变量」或「重建」';
    try { (globalThis as any).toastr?.warning(`SOLVE 没有处理第 ${index} 楼回复里的变量操作：${why}。${fix}，详情见 魔法棒 › SOLVE 调试 › 日志。`, 'SOLVE', { timeOut: 15000 }); } catch { /* no toasts */ }
  }
  private findParent(beforeIndex: number, archive?: import('../types.js').Archive): string {
    const links = archive ? new Map(Object.values(archive.commits).map(commit => [commit.id, commit.parentId])) : this.runtime.historyLinks();
    const messages = this.context().chat;
    let selected: string | undefined;
    for (let i = 0; i < beforeIndex; i++) {
      const head = messages[i]?.extra?.solve?.headId;
      if (!head || !links.has(head)) continue;
      if (selected && selected !== head) {
        let cursor = links.get(head) ?? null;
        const seen = new Set<string>();
        while (cursor && cursor !== selected) {
          if (seen.has(cursor)) fail('HISTORY_CYCLE', '父链出现循环');
          seen.add(cursor); cursor = links.get(cursor) ?? null;
        }
        if (cursor !== selected) fail('HISTORY_BRANCH_CONFLICT', '当前选中的回复版本与后续楼层不属于同一历史，请从变更处重放');
      }
      selected = head;
    }
    if (selected) return selected;
    const roots = [...links].filter(([, parentId]) => parentId === null);
    if (roots.length !== 1) fail('GENESIS_SELECTION', '无法确定当前开场分支的初始状态');
    return roots[0]![0];
  }
  private listen(event: string, fn: (...args: any[]) => unknown, last = false): void {
    const ctx = this.context(), name = ctx.eventTypes?.[event];
    if (!name || !ctx.eventSource) return;
    if (last && ctx.eventSource.makeLast) ctx.eventSource.makeLast(name, fn);
    else ctx.eventSource.on(name, fn);
    this.disposers.push(() => ctx.eventSource!.removeListener(name, fn));
  }
  private installEvents(): void {
    const onError = (error: unknown) => this.report(error);
    this.listen('CHAT_CHANGED', () => { this.readyState = false; this.reason = '聊天已切换'; this.operator?.abort(); this.adapter.invalidate(); this.runtime.invalidate(); this.record('CHAT_CHANGED', this.reason); });
    this.listen('GENERATION_STARTED', (type, _options, dryRun) => {
      if (dryRun || !this.ready || type === 'quiet' || type === 'impersonate') return;
      this.releaseGeneration?.(); this.generationEpoch++; this.finalizingGeneration = false;
      const ctx = this.context();
      this.generationRendered = ctx.saveChat && ctx.eventTypes?.CHARACTER_MESSAGE_RENDERED ? new Promise(resolve => { this.releaseGeneration = resolve; }) : undefined;
      this.generated = true; this.adapter.invalidate(); this.record('GENERATION_STARTED', '宿主开始生成');
    });
    this.listen('CHARACTER_MESSAGE_RENDERED', () => { this.releaseGeneration?.(); });
    this.listen('GENERATION_STOPPED', () => { this.generated = false; this.generationEpoch++; this.finalizingGeneration = false; this.releaseGeneration?.(); this.operator?.abort(); this.adapter.invalidate(); this.record('GENERATION_STOPPED', '生成已停止，不执行未完成的回复'); });
    this.listen('GENERATION_ENDED', async () => {
      if (!this.ready || !this.generated) return;
      this.generated = false; const epoch = this.generationEpoch; this.finalizingGeneration = true;
      try {
        // In 1.19 streaming, ENDED fires before render hooks and the final native save.
        // Wait for rendering, then join the native save queue before committing SOLVE.
        if (this.generationRendered) {
          await this.generationRendered;
          await new Promise(resolve => setTimeout(resolve, 0));
          if (epoch !== this.generationEpoch || this.disposed) return;
          this.assertBound(); await this.context().saveChat?.();
        }
        if (epoch === this.generationEpoch && !this.disposed && this.runtime.pendingCount && this.mode() === 'in-band') {
          // A draft left from an earlier failed save would block this reply: rebuild, redo that reply, then go on.
          const messageId = this.runtime.exportPending()[0]?.binding.messageId;
          await this.enqueue(() => this.dropStalePending('新回复到达时还有上次没保存的草稿'));
          const at = messageId ? this.context().chat.findIndex(m => m.extra?.solve?.messageId === messageId) : -1;
          if (messageId && at >= 0 && at < this.context().chat.length - 1) await this.redoReply(messageId);
        }
        if (epoch === this.generationEpoch && !this.disposed) await this.processMessage();
        const left = this.disposed ? undefined : this.unprocessedReply();
        if (left !== undefined && left === this.context().chat.length - 1) this.tellUnprocessed(left, '原因未知，见调试日志');
      } catch (error) {
        if (!this.disposed) {
          // A save that failed once (often a race with the tavern's own save around swipes) usually goes through on retry.
          if (await this.retrySilently(error)) return;
          onError(error);
          const left = this.unprocessedReply();
          if (left !== undefined) this.tellUnprocessed(left, describeError(error).message);
        }
      }
      finally { if (epoch === this.generationEpoch) { this.finalizingGeneration = false; this.notify(); } }
    });
    this.listen('MESSAGE_SWIPED', async (index: number) => {
      if (!this.ready) return;
      this.operator?.abort(); this.adapter.invalidate();
      // Selecting can lose a race with the tavern's own save right after a swipe: try again quietly before reporting.
      let failure: unknown;
      for (const wait of [0, 500, 1500]) {
        if (wait) { await new Promise(resolve => setTimeout(resolve, wait)); if (this.disposed) return; this.adapter.invalidate(); }
        try {
          const binding = this.adapter.binding(index);
          const head = await this.adapter.selectedHead(binding);
          await this.runtime.select(head ?? this.findParent(index));
          if (failure) this.record('AUTO_RETRY_SWIPE', `切换回复后恢复变量第一次失败（${describeError(failure).message}），重试成功`);
          failure = undefined;
          this.record('SWIPE_SELECTED', `已恢复楼层 ${index} 当前回复的变量状态`);
          break;
        } catch (error) { failure = error; }
      }
      if (failure) { this.readyState = false; onError(failure); return; }
      // Writing the variable snapshot back is secondary: the state is already selected; the next save writes it again.
      try { await this.syncVariableViews(); } catch (error) { this.record('SWIPE_SYNC_FAILED', `切换回复后写回变量快照失败（${describeError(error).message}），变量照常可用，下次保存时一并写入`, 'warning'); }
      // A swipe that carries operations but was never processed (its save failed earlier, SOLVE was off…): process it now.
      this.catchUp();
    });
    // An edited reply is reread automatically from that floor on (the operations are in the reply text; no model request).
    this.listen('MESSAGE_EDITED', async (index: number) => {
      const message = this.context().chat[index], headId = message?.extra?.solve?.headId;
      if (!headId) { this.record('MESSAGE_EDITED', '未归档楼层已编辑，变量历史保持原样'); return; }
      try {
        const commit = this.runtime.archive.commits[headId];
        if (commit?.textDigest && commit.textDigest === await hash(message!.mes)) { this.record('MESSAGE_EDITED', `楼层 ${index} 正文没有变化，变量历史保持原样`); return; }
      } catch { /* compare failed: replay to be safe */ }
      this.markDirty(`楼层 ${index} 已编辑，正在从这一楼自动重放`);
      try {
        await this.replayFrom(index);
        this.record('AUTO_REPLAY', `楼层 ${index} 已编辑，已自动从这一楼重放`);
      } catch (error) {
        this.reason = `楼层 ${index} 已编辑，自动重放没有完成：${describeError(error).message}。可以在调试面板的历史里修正后重放`;
        this.notify(); onError(error);
      }
    });
    const deleted = async () => {
      this.operator?.abort(); this.adapter.invalidate(); this.nativeHistoryChanged = true;
      const gap = preserveOrphanAncestors(this.runtime.archive, this.context().chat);
      if ((this.runtime.pendingCount || this.pendingImportError) && this.mode() === 'in-band') {
        // The draft was made before the deletion: rebuild instead of leaving the chat stuck.
        const messageId = this.runtime.exportPending()[0]?.binding.messageId;
        try {
          await this.enqueue(() => this.dropStalePending('删除消息时还有没保存的草稿'));
          if (messageId) await this.redoReply(messageId);
          return;
        } catch (error) { this.markDirty(describeError(error).message); onError(error); return; }
      }
      if (this.runtime.pendingCount || this.pendingImportError) { this.markDirty('删除后仍有待保存草稿，请先处理草稿，再重新检查历史'); return; }
      if (gap) { this.markDirty('中间历史已删除；已保留所需旧修订，请重放剩余的后续楼层'); return; }
      try {
        const archive = this.adapter.loadMemory(); if (!archive) fail('BROKEN_HISTORY', '当前聊天缺少归档');
        const head = this.findParent(this.context().chat.length, archive);
        this.runtime.invalidate(); this.runtime = this.createRuntime(archive, head); await this.runtime.ready(); this.assertBound();
        this.readyState = true; this.reason = '';
        this.context().chatMetadata.solve.storage = writeMessageVariableViews(this.context().chat, this.runtime.archive);
        this.record('HISTORY_TRIMMED', '已恢复删除后的剩余历史');
      } catch (error) { this.markDirty(describeError(error).message); onError(error); }
    };
    this.listen('MESSAGE_DELETED', deleted);
    this.listen('MESSAGE_SWIPE_DELETED', async event => {
      try {
        this.assertBound(); reconcileSwipeDeletion(this.context().chat, this.runtime.archive, event);
        await deleted();
      } catch (error) { this.markDirty(describeError(error).message); onError(error); }
    }, true);
    // Operation blocks never show in the chat (display only; the reply keeps them for replay and editing).
    const formatter = this.context().messageFormatter;
    if (formatter) this.disposers.push(hideOperationBlocks(formatter, () => !this.disposed));
  }
  /**
   * Before a story request goes out (native: the manifest's generate interceptor; script carriers: the fetch guard).
   * SOLVE never stops the tavern's request. While it is still saving or updating, the request waits (up to 60 s);
   * when the chat needs attention (not ready, unsaved operation, history not aligned) the request goes out anyway,
   * this turn just is not tracked, and the player is told why.
   */
  async intercept(chat: { mes: string }[], _contextSize?: number, _abort?: (immediate: boolean) => void): Promise<void> {
    if (this.context().chatId !== this.chatId) return;
    await this.beforeRequest(false);
    // Player actions reach the model as one line of narration (what they did in the status bar); operations never do.
    for (const message of chat) message.mes = promptText(message.mes);
  }
  /** fromFetch: the fetch guard also sees the operator model's own request, which must not wait for itself. */
  async beforeRequest(fromFetch = true): Promise<void> {
    if (this.busy && !(fromFetch && this.operator) && !this.options.allowRequestsDuringOperatorBusy) {
      this.record('REQUEST_WAITING', 'SOLVE 正在保存或更新变量，请求稍等后发送');
      if (!await this.whenIdle()) this.record('REQUEST_WAITING', '等待超过 60 秒，请求照常发送', 'warning');
    }
    const problem = this.requestProblem();
    if (problem) this.warnUntracked(problem);
  }
  /** Resolves true once nothing is running, false after maxMs. */
  async whenIdle(maxMs = 60_000): Promise<boolean> {
    const end = Date.now() + maxMs;
    while (this.busy && !this.disposed && Date.now() < end) await new Promise(resolve => setTimeout(resolve, 100));
    return !this.busy;
  }
  /** Why a story request now would not be tracked (undefined: it will be). */
  requestProblem(): string | undefined {
    try {
      if (!this.ready) return this.reason || 'SOLVE 状态未就绪';
      if (this.pendingImportError) return this.pendingImportError;
      // In-band drafts heal themselves when the next reply arrives (dropStalePending / redoReply).
      if (this.runtime.pendingCount) return this.mode() === 'in-band' ? undefined : '有一次操作没有保存成功';
      if (this.findParent(this.context().chat.length) !== this.runtime.headId) return '选中历史尚未对齐，请重放后续楼层';
    } catch (error) { return describeError(error).message; }
    return undefined;
  }
  private lastWarning?: { text: string; at: number };
  private warnUntracked(problem: string): void {
    this.record('REQUEST_UNTRACKED', `请求照常发送，这一轮不更新变量：${problem}`, 'warning');
    const now = Date.now();
    if (this.lastWarning?.text === problem && now - this.lastWarning.at < 60_000) return;
    this.lastWarning = { text: problem, at: now };
    try { (globalThis as any).toastr?.warning(`这一轮照常发送，但 SOLVE 不会更新变量：${problem}。可以在 魔法棒 › SOLVE 调试 › 概览 里处理。`, 'SOLVE', { timeOut: 12000 }); } catch { /* no toasts */ }
  }
  processMessage(index = this.context().chat.length - 1): Promise<Commit | undefined> {
    const candidate = this.context().chat[index];
    if (candidate?.is_user || candidate?.is_system) return Promise.resolve(undefined);
    const binding = this.adapter.binding(index);
    let text = this.context().chat[index]?.mes;
    return this.enqueue(async () => {
      this.assertReady(); if (this.pendingImportError) fail('PENDING_CONFLICT', this.pendingImportError); this.adapter.assertCurrent(binding);
      const message = this.context().chat[index];
      if (!message || message.is_user || message.is_system) return undefined;
      // Another extension may rewrite the reply right after it arrives (formatting, tables…): process what is there now.
      if (message.mes !== text) { this.record('REPLY_CHANGED', `楼层 ${index} 的回复在处理前被改动，按最新正文处理`); text = message.mes; }
      const raw = extractRawBlocks(text!);
      const archive = this.runtime.archive;
      const existingId = message.extra?.solve?.headId, existing = existingId ? archive.commits[existingId] : undefined;
      if (existing?.binding.swipeId === binding.swipeId && existing.textDigest === await hash(text!) && existing.actions.some(a => a.source === 'model')) {
        await this.runtime.select(existing.id); await this.syncVariableViews(); return existing;
      }
      if (raw.mutual && (!existing || existing.binding.swipeId !== binding.swipeId || existing.textDigest !== await hash(text!))) fail('UNTRUSTED_MUTUAL_BLOCK', '模型输出不能自行伪造玩家操作块');
      const parent = existing?.binding.swipeId === binding.swipeId && existing.parentId ? existing.parentId : this.findParent(index);
      await this.runtime.select(parent);
      const pending = this.runtime.exportPending().find(d => headKey(d.binding) === headKey(binding));
      if (pending) {
        const priorAction = pending.commit.actions.at(-1)!;
        return this.persist(() => this.runtime.submit(priorAction, binding, pending.text, { sourceText: text! }));
      }
      let operations: Batch;
      let finalText = text!;
      if (this.mode() === 'in-band') {
        // A reply without operations still advances the engine round.
        if (!raw.model && !this.core.definition.round) { await this.syncVariableViews(); return undefined; }
        operations = raw.model ? parseOperations(raw.model) : [];
      } else if (raw.model) {
        // Written earlier (by the operator model, 单独生成变量 or by hand): the reply carries its operations.
        operations = parseOperations(raw.model);
      } else {
        const skip = this.operatorSkip(text!);
        if (skip) { this.record('OPERATOR_SKIPPED', `楼层 ${index} 没有请求操作模型：${skip}`); await this.syncVariableViews(); return undefined; }
        const prompt = this.operatorPrompt(index);
        const output = await this.requestOperator(prompt, index);
        this.adapter.assertCurrent(binding);
        operations = parseOperatorOutput(output);
        finalText = text!.trimEnd() + `\n<solve_operate>\n${JSON.stringify(operations)}\n</solve_operate>`;
      }
      const actionId = 'model:' + await hash({ messageId: binding.messageId, swipeId: binding.swipeId, parent, sourceText: text!, operations });
      // The round is fixed in the action, so Replay and Restore reproduce it exactly.
      const authorInputs = this.core.definition.round ? { solveRound: nextRound(this.core.definition, this.runtime.getState(), index) } : undefined;
      return this.persist(() => this.runtime.submit({ actionId, kind: 'operations', source: 'model', operations, ...(authorInputs ? { authorInputs } : {}) }, binding, finalText, { sourceText: text! }));
    });
  }
  private enqueue<T>(task: () => Promise<T>): Promise<T> {
    this.queued++; this.notify();
    const promise = this.processing.catch(() => undefined).then(() => { this.assertBound(); return task(); }).catch(error => { this.report(error); throw error; });
    this.processing = promise;
    return promise.finally(() => { this.queued--; this.notify(); });
  }
  /** ⚙ 设置 › 变量更新 of this browser, once the player saved any (otherwise the card's attach options decide). */
  private updatePrefs(): OperatorPrefs | undefined {
    const scope = globalThis as any;
    try { if (!scope.localStorage?.getItem(UPDATE_PREFS)) return undefined; } catch { return undefined; }
    return readOperatorPrefs(scope);
  }
  /** Who writes the operations: the story model (in-band) or a separate request (out-of-band). The player's choice wins. */
  mode(): 'in-band' | 'out-of-band' { return this.updatePrefs()?.mode ?? this.options.mode ?? 'in-band'; }
  /** Why the operator model is not asked automatically for this reply (undefined: ask). */
  private operatorSkip(text: string): string | undefined {
    const body = stripBlocks(text).trim();
    if (!body) return '回复是空的（可能被截断，或只有被正则去掉的思考内容）';
    const p = this.updatePrefs(); if (!p) return undefined;
    if (!p.auto) return '设置里关掉了自动请求，可以点「单独生成变量」';
    if (p.minLength > 0 && body.length < p.minLength) return `回复不到 ${p.minLength} 字`;
    const trigger = p.trigger.trim(), re = /^\/(.+)\/([a-z]*)$/u.exec(trigger);
    if (trigger) {
      let hit: boolean;
      try { hit = re ? new RegExp(re[1]!, re[2]).test(text) : text.includes(trigger); } catch { hit = text.includes(trigger); }
      if (!hit) return `回复里没有触发标签 ${trigger}`;
    }
    return undefined;
  }
  private operatorPrompt(index: number): string {
    const state = this.runtime.getState(), def = this.core.definition, prefs = this.updatePrefs();
    const history = Math.max(1, prefs?.history ?? 4);
    const lines = this.context().chat.slice(Math.max(0, index - history + 1), index + 1)
      .map((m, i, all) => `${i === all.length - 1 ? '【最新回复】' : ''}${m.is_user ? '玩家' : (m.name || '角色')}：${stripBlocks(m.mes ?? '').trim()}`);
    const format = prefs?.format ?? this.options.operatorFormat;
    const encoded = format === 'toon' ? toToon(def, state, { view: 'operator' }) : toJson(def, state, { view: 'operator' });
    const feedback = this.runtime.getCommit()?.feedback ?? [];
    return [
      '# 任务\n你是变量更新器，不写故事。读下面的说明、当前变量和最近的对话，只根据【最新回复】里发生的事，写出这一轮要做的变量操作。'
        + '\n只输出一个 <solve_operate> 块（里面是操作的 JSON 数组），不要输出别的文字；这一轮没有变化就输出 <solve_operate>[]</solve_operate>。',
      sop(), schemaText(def, state), guide(def, state),
      `# 当前变量（${format === 'toon' ? 'TOON' : 'JSON'}）\n${encoded}`,
      ...(feedback.length ? [`# 上一轮的反馈\n${JSON.stringify(feedback)}`] : []),
      `# 最近的对话\n${lines.join('\n\n')}`,
      '# 现在输出\n只输出 <solve_operate> 块。',
    ].join('\n\n');
  }
  /** The request for the operator model: the player's settings, else the card's attach options. */
  private operatorRequestFn(): (prompt: string, signal: AbortSignal) => Promise<string> {
    const prefs = this.updatePrefs();
    if (prefs && prefs.source !== 'same') return prefsRequest(globalThis, prefs);
    if (this.options.operatorRequest) return this.options.operatorRequest;
    if (this.options.operatorProfileId) {
      const profileId = this.options.operatorProfileId;
      return async (prompt, signal) => {
        const service = this.context().ConnectionManagerRequestService;
        if (!service) fail('OPERATOR_NOT_CONFIGURED', '需要操作模型的独立连接预设或请求函数');
        const result = await service.sendRequest(profileId, prompt, 2048, { stream: false, signal, extractData: true, includePreset: true });
        return typeof result === 'string' ? result : result?.content;
      };
    }
    if ((globalThis as any).SillyTavern?.getContext) return prefsRequest(globalThis, prefs ?? readOperatorPrefs(globalThis));
    fail('OPERATOR_NOT_CONFIGURED', '需要操作模型的独立连接预设或请求函数');
  }
  /** Last operator request (⚙ 设置 › 变量更新 › 最近一次). */
  lastOperator?: { ok: boolean; at: number; ms?: number; chars?: number; error?: string };
  private toastOperator(kind: 'info' | 'error' | 'clear', text = ''): void {
    const t = (globalThis as any).toastr, prefs = this.updatePrefs();
    try {
      if (kind === 'clear') { if (this.operatorToast) t?.clear(this.operatorToast); this.operatorToast = undefined; return; }
      if (kind === 'info' && prefs?.notify.working === false) return;
      if (kind === 'error' && prefs?.notify.failed === false) return;
      const el = kind === 'info' ? t?.info(text, 'SOLVE', { timeOut: 0, extendedTimeOut: 0 }) : t?.error(text, 'SOLVE', { timeOut: 15000 });
      if (kind === 'info') this.operatorToast = el;
    } catch { /* no toasts */ }
  }
  private operatorToast: unknown;
  private async requestOperator(prompt: string, index?: number): Promise<string> {
    if (this.operator) fail('OPERATOR_BUSY', '操作模型任务正在运行');
    const prefs = this.updatePrefs();
    const tries = 1 + Math.max(0, prefs?.retries ?? 0);
    const timeoutMs = prefs ? prefs.timeout * 1000 : this.options.operatorTimeoutMs ?? 60_000;
    const request = this.operatorRequestFn();
    const started = performance.now(); this.record('OPERATOR_STARTED', `独立操作模型请求开始${index === undefined ? '' : `（楼层 ${index}）`}`);
    this.toastOperator('info', '正在更新变量…');
    let lastError: unknown, cancelled = false;
    try {
      for (let attempt = 1; attempt <= tries; attempt++) {
        const controller = new AbortController(); this.operator = controller;
        const timer = setTimeout(() => controller.abort(new Error(`操作模型超时（${Math.round(timeoutMs / 1000)} 秒）`)), timeoutMs);
        try {
          const aborted = new Promise<never>((_resolve, reject) => {
            controller.signal.addEventListener('abort', () => reject(controller.signal.reason ?? new Error('操作模型已取消')), { once: true });
          });
          const text = await Promise.race([request(prompt, controller.signal), aborted]);
          controller.signal.throwIfAborted();
          if (typeof text !== 'string' || !text.trim()) fail('OPERATOR_RESPONSE', '操作模型没有返回文本');
          parseOperatorOutput(text); // a reply that cannot be read counts as a failed try
          this.record('OPERATOR_COMPLETED', `操作模型返回 ${text.length} 字符${attempt > 1 ? `（第 ${attempt} 次）` : ''}`, 'info', performance.now() - started);
          this.lastOperator = { ok: true, at: Date.now(), ms: performance.now() - started, chars: text.length };
          return text;
        } catch (error) {
          lastError = error;
          // Cancelled by the player, a swipe or a chat switch: do not try again.
          if (controller.signal.aborted && !String((controller.signal.reason as Error | undefined)?.message ?? '').includes('超时')) { cancelled = true; break; }
          // The same limit would cut it again.
          if ((error as { code?: string } | undefined)?.code === 'OPERATOR_TRUNCATED') break;
          if (attempt < tries) this.record('OPERATOR_RETRY', `操作模型第 ${attempt} 次没有成功（${describeError(error).message}），重试`, 'warning');
        } finally { clearTimeout(timer); if (this.operator === controller) this.operator = undefined; }
      }
      const why = describeError(lastError).message;
      this.lastOperator = { ok: false, at: Date.now(), ms: performance.now() - started, error: why };
      this.toastOperator('clear');
      if (!cancelled) this.toastOperator('error', `变量没有更新：${why}。可以点输入框上方的「单独生成变量」再试。`);
      throw lastError;
    } finally { this.toastOperator('clear'); this.notify(); }
  }
  private async persist<T>(task: () => Promise<T>, align = true): Promise<T> {
    try {
      if (this.nativeHistoryChanged) { await this.adapter.reconcileNativeSave(this.runtime.archive); this.nativeHistoryChanged = false; }
      const result = await measure(this.performance, 'controller.mutation', task);
      await measure(this.performance, 'controller.cache', () => this.useCache(cache => cache.put(this.runtime.archive, this.runtime.headId, this.runtime.getState(), this.history)));
      this.record('ARCHIVED', '状态已保存并通过回读核验');
      if (align) this.checkAlignment();
      return result;
    } finally {
      await this.useCache(cache => cache.savePending(this.runtime.sessionId, this.runtime.exportPending()));
    }
  }
  async submit(operations: Batch, options: { actionId?: string; index?: number; authorInputs?: Json; expectedHead?: string } = {}): Promise<Commit> {
    return this.submitUser({ actionId: options.actionId ?? id('action'), kind: 'operations', source: 'user', operations,
      ...(options.authorInputs !== undefined ? { authorInputs: options.authorInputs } : {}) }, options.index, options.expectedHead);
  }
  async setModule(module: string, enabled: boolean, options: { actionId?: string; index?: number } = {}): Promise<Commit> {
    return this.submitUser({ actionId: options.actionId ?? id('action'), kind: 'module', source: 'user', module, enabled }, options.index);
  }
  /**
   * Revert the latest player action on the current reply (status bar 撤销). The archive keeps every revision, so this
   * re-selects the revision before that action and restores its message text; nothing is recomputed.
   */
  async undoUser(options: { index?: number } = {}): Promise<Commit> {
    this.assertReady();
    const index = options.index ?? this.lastAssistantIndex(), binding = this.adapter.binding(index);
    return this.enqueue(async () => {
      this.assertReady(); if (this.pendingImportError) fail('PENDING_CONFLICT', this.pendingImportError); this.adapter.assertCurrent(binding);
      const head = await this.adapter.selectedHead(binding);
      if (!head) fail('NO_SWIPE_STATE', '当前回复尚未完成变量同步');
      if (this.runtime.headId !== head) await this.runtime.select(head);
      const current = this.runtime.getCommit(head)!, last = current.actions.at(-1);
      if (!last || last.source !== 'user') fail('NOTHING_TO_UNDO', '当前回复没有可以撤销的玩家操作');
      const want = canonical(current.actions.slice(0, -1)), archive = this.runtime.archive;
      const before = Object.values(archive.commits).find(c => c.id !== current.id && c.parentId === current.parentId
        && headKey(c.binding) === headKey(current.binding) && canonical(c.actions) === want);
      if (!before) fail('UNDO_UNAVAILABLE', '找不到这次操作之前的记录，无法撤销');
      const message = this.context().chat.find(m => m.extra?.solve?.messageId === binding.messageId)!;
      const prefix = message.mes.replace(/<solve_mutual_operate>[\s\S]*?<\/solve_mutual_operate>/gu, '').trimEnd();
      const users = current.actions.slice(0, -1).filter(a => a.source === 'user');
      const candidates = users.length ? [prefix + `\n<solve_mutual_operate>\n${JSON.stringify(users)}\n</solve_mutual_operate>`] : [prefix, message.mes.replace(/\n?<solve_mutual_operate>[\s\S]*?<\/solve_mutual_operate>/gu, '')];
      let text: string | undefined;
      for (const candidate of candidates) if (await hash(candidate) === before.textDigest) { text = candidate; break; }
      if (text === undefined) fail('UNDO_UNAVAILABLE', '回复正文已变化，无法撤销');
      archive.heads[headKey(binding)] = before.id;
      const draft = { archive, commit: before, binding, text, sourceTextDigest: await hash(message.mes), expectedHead: this.runtime.headId, prepared: true as const };
      return this.persist(() => this.runtime.savePrepared(draft, message.mes));
    });
  }
  /** Player settings: list caps/warnings and per-change limits. `null` restores a default. */
  async setSettings(settings: SettingsPatch, options: { actionId?: string; index?: number } = {}): Promise<Commit> {
    return this.submitUser({ actionId: options.actionId ?? id('action'), kind: 'settings', source: 'user', settings: clone(settings) }, options.index);
  }
  getSettings() {
    const state = this.getState(), def = this.core.definition;
    return {
      lists: Object.fromEntries(Object.entries(def.lists ?? {}).map(([pattern, rule]) => [pattern, { ...listLimit(def, state, pattern)!, default: { max: rule.max, warn: rule.warn }, ...(rule.label ? { label: rule.label } : {}) }])),
      maxDelta: Object.fromEntries(Object.entries(def.numeric ?? {}).filter(([, rule]) => rule.maxDelta !== undefined).map(([pattern, rule]) => [pattern, { value: state.engineState.settings?.maxDelta?.[pattern] ?? rule.maxDelta!, default: rule.maxDelta! }])),
    };
  }
  /** Derived values (e.g. WOD transcendence) keyed by JSON pointer, for status bars. */
  getComputed() { return computeAll(this.core.definition, this.getState()); }
  /** Presentation metadata (labels, spoiler levels, widgets, layout) declared by the structure. */
  getDisplay() { return clone(this.core.definition.display ?? {}); }
  getMigration() { return clone(this.getState().engineState.migration); }
  private lastAssistantIndex(): number { return this.context().chat.findLastIndex(m => !m.is_user && !m.is_system); }
  private async submitUser(action: Action, index = this.lastAssistantIndex(), expectedHead?: string): Promise<Commit> {
    this.assertReady();
    const binding = this.adapter.binding(index), input = clone(action);
    return this.enqueue(async () => {
      this.assertReady(); if (this.pendingImportError) fail('PENDING_CONFLICT', this.pendingImportError); this.adapter.assertCurrent(binding);
      this.findParent(this.context().chat.length);
      const message = this.context().chat.find(m => m.extra?.solve?.messageId === binding.messageId)!;
      const head = await this.adapter.selectedHead(binding);
      if (!head) fail('NO_SWIPE_STATE', '当前回复尚未完成变量同步');
      if (expectedHead !== undefined && (expectedHead !== head || expectedHead !== this.runtime.headId)) fail('HEAD_CHANGED', '状态已变化或目标楼层不一致，请重新预演；当前执行位置未改变');
      if (this.runtime.headId !== head) await this.runtime.select(head);
      const commit = this.runtime.getCommit(head)!;
      const existing = commit.actions.filter(a => a.source === 'user');
      const prefix = message.mes.replace(/<solve_mutual_operate>[\s\S]*?<\/solve_mutual_operate>/gu, '').trimEnd();
      const actions = existing.some(a => a.actionId === input.actionId) ? existing : [...existing, input];
      const text = prefix + `\n<solve_mutual_operate>\n${JSON.stringify(actions)}\n</solve_mutual_operate>`;
      return this.persist(() => this.runtime.submit(input, binding, text, { sourceText: message.mes, expectedHead }));
    });
  }
  /** Explicitly reinterpret an edited selected message; unaffected old branches remain archived. */
  async replayMessage(index: number): Promise<Commit> {
    if (this.context().chatId !== this.chatId) return Promise.reject(new Error('请先绑定当前聊天'));
    const binding = this.adapter.binding(index);
    return this.enqueue(async () => { const commit = await this.replayOne(index, binding); this.checkAlignment(); return commit; });
  }
  private async replayOne(index: number, binding: import('../types.js').Binding): Promise<Commit> {
      this.adapter.assertCurrent(binding);
      if (this.runtime.pendingCount || this.pendingImportError) fail('PENDING_SAVE', '请先处理待保存草稿');
      const message = this.context().chat[index]!;
      const originalText = message.mes;
      const archive = this.nativeHistoryChanged ? this.adapter.loadMemory()! : this.runtime.archive;
      const old = archive?.commits[message.extra?.solve?.headId];
      if (!old) fail('NO_SWIPE_STATE', '该回复没有可重放的归档');
      const raw = extractRawBlocks(originalText), actions: Action[] = [];
      const prior = old.actions.find(a => a.source === 'model');
      // An operation-free reply still carries its engine round and must be replayed with it.
      if (raw.model || (this.core.definition.round && prior)) {
        actions.push({ actionId: prior?.actionId ?? id('model-replay'), kind: 'operations', source: 'model', operations: raw.model ? parseOperations(raw.model) : [],
          ...(prior?.authorInputs !== undefined ? { authorInputs: prior.authorInputs } : {}) });
      }
      if (raw.mutual) {
        const values = JSON.parse(raw.mutual); assertJson(values);
        if (!Array.isArray(values)) fail('MUTUAL_FORMAT', '玩家动作块必须为有序数组');
        for (let i = 0; i < values.length; i++) {
          const value: any = values[i];
          if (value?.kind === 'operations' || value?.kind === 'module' || value?.kind === 'settings') {
            if (value.source !== 'user' || typeof value.actionId !== 'string') fail('MUTUAL_FORMAT', '玩家动作身份无效');
            if (value.kind === 'operations') parseOperations(JSON.stringify(value.operations));
            else if (value.kind === 'settings') { if (!value.settings || typeof value.settings !== 'object' || Array.isArray(value.settings)) fail('MUTUAL_FORMAT', '设置动作无效'); }
            else if (typeof value.module !== 'string' || typeof value.enabled !== 'boolean') fail('MUTUAL_FORMAT', '模块动作无效');
            actions.push(value as Action);
          } else actions.push({ actionId: `replay:${old.id}:${i}`, kind: 'operations', source: 'user', operations: parseOperations(JSON.stringify(value)) });
        }
      }
      const parent = this.findParent(index, archive);
      if (this.nativeHistoryChanged) {
        await this.adapter.reconcileNativeSave(archive); this.nativeHistoryChanged = false;
        const sourceHead = archive.commits[this.runtime.headId] ? this.runtime.headId : parent;
        this.runtime.invalidate(); this.runtime = this.createRuntime(archive, sourceHead); await this.runtime.ready();
      }
      const result = await replay(this.core, archive, [old.id], parent, { [old.id]: actions });
      const commit = result.archive.commits[result.headId]!;
      const { generationToken: _generationToken, ...storedBinding } = binding;
      commit.binding = storedBinding; commit.textDigest = await hash(originalText);
      result.archive.heads[headKey(binding)] = commit.id;
      await this.persist(() => this.runtime.savePrepared({ archive: result.archive, commit, binding, text: originalText,
        sourceTextDigest: commit.textDigest, expectedHead: this.runtime.headId, prepared: true }, originalText), false);
      this.readyState = true; this.reason = '';
      this.record('REPLAY_COMPLETED', `楼层 ${index} 已重放，旧修订保留`);
      return commit;
  }
  replayFrom(index: number): Promise<void> {
    this.assertBound();
    if (!Number.isInteger(index) || index < 0 || index >= this.context().chat.length) return Promise.reject(new Error('请选择有效的起始楼层'));
    const targets = this.context().chat.flatMap((message, i) => i >= index && !message.is_user && !message.is_system && message.extra?.solve?.headId ? [{ index: i, binding: this.adapter.binding(i) }] : []);
    return this.enqueue(async () => {
      try { for (const target of targets) await this.replayOne(target.index, target.binding); this.checkAlignment(); }
      catch (error) { this.markDirty(`重放中断：${describeError(error).message}。请修正后从该楼层继续重放`); throw error; }
    });
  }
  private checkAlignment(): void {
    try { if (this.findParent(this.context().chat.length) !== this.runtime.headId) this.markDirty('后续历史尚未对齐，请重放后续楼层'); }
    catch (error) { this.markDirty(describeError(error).message); }
  }
  private markDirty(reason: string): void {
    this.readyState = false; this.reason = reason; this.operator?.abort(); this.adapter.invalidate(); this.runtime.invalidate(); this.record('HISTORY_DIRTY', reason, 'warning');
  }
  getStatus() {
    let aligned = this.ready, reason = this.ready ? '' : this.reason;
    if (aligned && this.runtime) {
      try { if (this.findParent(this.context().chat.length) !== this.runtime.headId) { aligned = false; reason = '选中历史尚未对齐，请重放后续楼层'; } }
      catch (error) { aligned = false; reason = describeError(error).message; }
    }
    return {
      ready: aligned, busy: this.busy, reason, chatId: this.context().chatId, boundChatId: this.chatId,
      definition: { id: this.core.definition.id, version: this.core.definition.version, fingerprint: this.core.definition.fingerprint },
      sessionId: this.runtime?.sessionId, headId: this.runtime?.headId, pendingCount: (this.runtime?.pendingCount ?? 0) + (this.pendingImportError ? 1 : 0), pendingImportError: this.pendingImportError,
      cache: { enabled: Boolean(this.cache), error: this.cacheError, source: this.cache?.lastRestoreSource ?? 'archive' },
      facetHooksPending: this.runtime?.pendingHookCount ?? 0,
      capabilities: inspectCapabilities(this.context(), this.hostVersion), mode: this.mode(), cardMode: this.options.mode ?? 'in-band', operatorBusy: Boolean(this.operator),
      generating: this.generated || this.finalizingGeneration,
    };
  }
  getState() { this.assertReady(); return this.runtime.getState(); }
  getValue(path: string) { const state = this.getState(); const graph = new EntityGraph(this.core.definition, state); return clone(at(state.data, graph.resolve(path))); }
  getGuide(tag?: string): string {
    this.assertReady();
    if (this.findParent(this.context().chat.length) !== this.runtime.headId) fail('STATE_NOT_ALIGNED', '模型输入尚未对齐当前选中的历史');
    return guide(this.core.definition, this.runtime.getState(), tag);
  }
  getProjectedState(options: ProjectionOptions = {}) { return project(this.core.definition, this.getState(), options); }
  getContextPreview(options: ProjectionOptions = {}) {
    const state = this.getState(), def = this.core.definition;
    return { json: toJson(def, state, options), toon: toToon(def, state, options), sop: sop(), schema: schemaText(def, state), guide: guide(def, state), feedback: this.runtime.getCommit()?.feedback ?? [], operatorPrompt: this.operatorPrompt(this.lastAssistantIndex()) };
  }
  getDefinitionInfo() {
    const def = this.core.definition;
    return clone({ id: def.id, version: def.version, fingerprint: def.fingerprint, schema: def.schemaShape, entities: def.entities ?? [], references: def.refs ?? [],
      modules: def.modules ?? {}, numeric: def.numeric ?? {}, readonly: def.readonly ?? [], internal: def.internal ?? [], templates: def.templates ?? {}, prefabs: def.prefabs ?? {}, customViews: Object.keys(def.views ?? {}), hasStateValidator: Boolean(def.validateState) });
  }
  getModules() {
    const state = this.getState(); return Object.entries(this.core.definition.modules ?? {}).map(([name, spec]) => ({ name, ...clone(spec), enabled: isModuleEnabled(this.core.definition, state, name), preference: state.engineState.activeModules[name] }));
  }
  clearDiagnostics(): void { this.journal.clear(); this.notify(); }
  getMessages() {
    return this.context().chat.map((message, index) => ({ index, role: message.is_user ? 'user' : message.is_system ? 'system' : 'assistant',
      swipeIndex: message.swipe_id ?? 0, swipeCount: message.swipes?.length ?? 1, messageId: message.extra?.solve?.messageId as string | undefined,
      swipeId: message.extra?.solve?.swipeId as string | undefined, headId: message.extra?.solve?.headId as string | undefined, text: message.mes }));
  }
  getHistory() {
    const archive = this.runtime.archive;
    return Object.values(archive.commits).map(commit => ({ ...commit, current: commit.id === this.runtime.headId, selected: archive.heads[headKey(commit.binding)] === commit.id }));
  }
  async inspectCommit(commitId = this.runtime.headId) {
    this.assertBound(); const archive = this.runtime.archive;
    if (!archive.commits[commitId]) commitId = readToken(commitId);
    const commit = archive.commits[commitId];
    if (!commit) fail('BROKEN_HISTORY', '找不到指定提交');
    const state = await restore(archive, commitId), graph = new EntityGraph(this.core.definition, state);
    return { commit: clone(commit), state, entities: [...graph.entities.values()].map(clone), references: clone(graph.refs) };
  }
  async preview(operations: Batch, authorInputs?: Json) {
    this.assertReady(); const before = this.runtime.getState(), baseHeadId = this.runtime.headId;
    const result = await this.core.execute(clone(operations), before, { source: 'user', authorInputs });
    return { ...result, baseHeadId, dataPatch: jsonpatch.compare(before.data, result.state.data), enginePatch: jsonpatch.compare(before.engineState, result.state.engineState) };
  }
  async compareCommits(beforeId: string, afterId: string) {
    const archive = this.runtime.archive;
    if (!archive.commits[beforeId]) beforeId = readToken(beforeId);
    if (!archive.commits[afterId]) afterId = readToken(afterId);
    const [before, after] = await Promise.all([restore(archive, beforeId), restore(archive, afterId)]);
    return { beforeId, afterId, dataPatch: jsonpatch.compare(before.data, after.data), enginePatch: jsonpatch.compare(before.engineState, after.engineState) };
  }
  getPending() { return this.runtime.exportPending(); }
  /**
   * After a failed save: retry quietly a few times before telling the player. Returns true once nothing is left
   * unsaved and the latest reply is processed.
   */
  private async retrySilently(error: unknown): Promise<boolean> {
    if (!this.runtime.pendingCount && !this.pendingImportError) return false;
    const why = describeError(error).message;
    for (const wait of [400, 1200, 3000]) {
      await new Promise(resolve => setTimeout(resolve, wait));
      if (this.disposed) return false;
      if (!this.runtime.pendingCount && !this.pendingImportError) break;
      try { await this.retryPending(); }
      catch (again) { this.record('AUTO_RETRY_FAILED', `自动重试保存没有成功：${describeError(again).message}`, 'warning'); continue; }
    }
    if (this.runtime.pendingCount || this.pendingImportError) return false;
    this.record('AUTO_RETRY_SAVED', `保存失败（${why}），已自动重试保存成功`);
    this.notify();
    return this.unprocessedReply() === undefined;
  }
  /** 重新处理变量: read the latest reply's operations again (a draft left unsaved is retried first). */
  async reprocessLatest(): Promise<Commit | undefined> {
    this.assertBound();
    if (this.runtime.pendingCount || this.pendingImportError) {
      const commit = await this.retryPending();
      if (this.unprocessedReply() === undefined) return commit;
    }
    const index = this.lastAssistantIndex();
    if (index < 0) fail('NO_REPLY', '还没有可处理的回复');
    if (!this.ready) fail('STATE_NOT_READY', this.reason || 'SOLVE 状态尚未就绪，可以先试「重建」');
    const message = this.context().chat[index]!;
    const commit = message.extra?.solve?.headId && this.runtime.archive.commits[message.extra.solve.headId]
      ? await this.replayMessage(index) : await this.processMessage(index);
    this.record('REPROCESSED', `已重新处理楼层 ${index} 的变量操作`);
    return commit;
  }
  /**
   * 重建: forget any unsaved draft and rebuild the variables from what the chat file holds, then process the latest
   * reply if it was never processed. For a chat stuck after an error.
   */
  async rebuild(): Promise<void> {
    this.assertBound();
    this.operator?.abort();
    await this.enqueue(() => this.dropStalePending('玩家要求重建'));
    this.checkAlignment();
    await this.syncVariableViews().catch(() => undefined);
    const left = this.unprocessedReply();
    if (left !== undefined) await this.processMessage(left);
    this.record('REBUILT', this.ready ? '已按聊天记录重建变量' : `已重建，但后续楼层还需要重放：${this.reason}`, this.ready ? 'info' : 'warning');
    this.notify();
  }
  /**
   * 单独生成变量: ask a model for the operations of one reply (when the story model left them out), write them into
   * the reply as its operation block, then process it (and replay the floors after it).
   */
  async generateOperations(request?: (prompt: string, signal: AbortSignal) => Promise<string>, index = this.lastAssistantIndex()): Promise<{ operations: number }> {
    this.assertBound();
    if (index < 0) fail('NO_REPLY', '还没有可处理的回复');
    if (this.runtime.pendingCount || this.pendingImportError) await this.enqueue(() => this.dropStalePending('单独生成变量前还有没保存的草稿'));
    const binding = this.adapter.binding(index);
    const prompt = await this.enqueue(async () => {
      this.assertReady(); this.adapter.assertCurrent(binding);
      await this.runtime.select(this.findParent(index));
      return this.operatorPrompt(index);
    });
    let output: string;
    if (!request) output = await this.requestOperator(prompt, index);
    else {
      if (this.operator) fail('OPERATOR_BUSY', '操作模型任务正在运行');
      const controller = new AbortController(); this.operator = controller;
      const started = performance.now(); this.record('OPERATOR_STARTED', `单独生成楼层 ${index} 的变量`);
      try {
        const timer = setTimeout(() => controller.abort(new Error('生成变量超时')), this.options.operatorTimeoutMs ?? 120_000);
        try { output = await request(prompt, controller.signal); } finally { clearTimeout(timer); }
      } finally { if (this.operator === controller) this.operator = undefined; }
      controller.signal.throwIfAborted();
      if (typeof output !== 'string' || !output.trim()) fail('OPERATOR_RESPONSE', '模型没有返回内容');
      this.record('OPERATOR_COMPLETED', `返回 ${output.length} 字符`, 'info', performance.now() - started);
    }
    const operations = parseOperatorOutput(output);
    this.adapter.assertCurrent(binding);
    const ctx = this.context(), message = ctx.chat[index]!;
    // Keep the player's block; replace (or add) the model's.
    const mutual = /<solve_mutual_operate>[\s\S]*?<\/solve_mutual_operate>/u.exec(message.mes)?.[0];
    const body = message.mes.replace(/<solve_(mutual_)?operate>[\s\S]*?<\/solve_\1operate>/gu, '').trimEnd();
    message.mes = body + `\n<solve_operate>\n${JSON.stringify(operations)}\n</solve_operate>` + (mutual ? '\n' + mutual : '');
    if (Array.isArray(message.swipes) && typeof message.swipe_id === 'number') message.swipes[message.swipe_id] = message.mes;
    try { ctx.updateMessageBlock?.(index, message); } catch { /* the text is saved either way */ }
    await ctx.saveChat?.();
    if (message.extra?.solve?.headId && this.runtime.archive.commits[message.extra.solve.headId]) await this.replayFrom(index);
    else {
      await this.processMessage(index);
      if (index < ctx.chat.length - 1) await this.replayFrom(index + 1);
    }
    this.record('OPERATIONS_GENERATED', `楼层 ${index} 已写入 ${Array.isArray(operations) ? operations.length : 1} 组生成的变量操作`);
    return { operations: Array.isArray(operations) ? operations.length : 1 };
  }
  retryPending(): Promise<Commit | undefined> {
    let redo: string | undefined;
    return this.enqueue(async () => {
      const draft = this.runtime.exportPending()[0]; if (!draft) fail('NO_PENDING_SAVE', '没有待保存操作');
      try {
        const index = this.context().chat.findIndex(m => m.extra?.solve?.messageId === draft.binding.messageId);
        if (index < 0) fail('PENDING_CONFLICT', '待保存操作所属消息已不存在');
        const binding = this.adapter.binding(index);
        if (headKey(binding) !== headKey(draft.binding)) fail('PENDING_CONFLICT', '请切回待保存操作所属的回复版本');
        if (draft.prepared) {
          const commit = await this.persist(() => this.runtime.savePrepared({ ...draft, binding }, this.context().chat[index]!.mes), false);
          this.readyState = true; this.reason = ''; this.checkAlignment(); return commit;
        }
        return await this.persist(() => this.runtime.submit(draft.commit.actions.at(-1)!, binding, draft.text, { sourceText: this.context().chat[index]!.mes }));
      } catch (error) {
        if (!this.canRedoPending(error)) throw error;
        redo = draft.binding.messageId;
        await this.dropStalePending(`重试保存时这份草稿已经过时（${describeError(error).message}）`);
        return undefined;
      }
    }).then(commit => redo ? this.redoReply(redo) : commit);
  }
  /**
   * In-band drafts can always be rebuilt: the operations live in the reply text. A draft made before the chat changed
   * (swipes, deletions, regeneration, a half-written save) is dropped and its reply processed again on the current history.
   */
  private canRedoPending(error: unknown): boolean {
    if (this.mode() !== 'in-band') return false;
    return ['ARCHIVE_OWNERSHIP', 'PENDING_CONFLICT', 'PENDING_TEXT_CHANGED', 'PENDING_INVALID', 'STATE_NOT_ALIGNED', 'STALE_ACTION', 'HEAD_CHANGED', 'STALE_BINDING', 'SOURCE_TEXT_CHANGED']
      .includes(describeError(error).code);
  }
  /** Runs inside the queue: forget the draft, rebuild the runtime from the chat as it is now. */
  private async dropStalePending(why: string): Promise<void> {
    if (this.cache) await this.useCache(cache => cache.savePending(this.runtime.sessionId, []));
    this.runtime.discardPending(); this.pendingImportError = undefined;
    this.adapter.invalidate();
    const archive = this.adapter.loadMemory(); if (!archive) fail('BROKEN_HISTORY', '当前聊天缺少归档');
    preserveOrphanAncestors(archive, this.context().chat);
    const head = this.findParent(this.context().chat.length, archive);
    this.runtime.invalidate(); this.runtime = this.createRuntime(archive, head); await this.runtime.ready(); this.assertBound();
    this.readyState = true; this.reason = '';
    this.record('PENDING_REBUILT', `${why}；已放弃这份草稿，按当前聊天重建历史，再从回复正文重新处理`, 'warning');
  }
  /** Process the reply that carried a dropped draft again, if it is still in the chat. */
  private async redoReply(messageId: string): Promise<Commit | undefined> {
    const index = this.context().chat.findIndex(m => m.extra?.solve?.messageId === messageId);
    if (index < 0) { this.record('PENDING_REBUILT', '草稿所属的回复已经不在聊天里，不需要重新处理'); return undefined; }
    return this.processMessage(index);
  }
  discardPending(): Promise<void> {
    return this.enqueue(async () => {
      if (this.runtime.busy) fail('RUNTIME_BUSY', '请等待写入完成');
      const draft = this.runtime.exportPending()[0];
      if (draft) {
        const file = await this.adapter.readFile();
        const remote = file ? archiveFromChat(file[0].chat_metadata ?? {}, file.slice(1) as import('./sillytavern.js').HostMessage[]) : undefined;
        if (remote?.commits[draft.commit.id]) {
          const index = this.context().chat.findIndex(m => m.extra?.solve?.messageId === draft.binding.messageId);
          const binding = this.adapter.binding(index);
          if (draft.prepared) {
            await this.persist(() => this.runtime.savePrepared({ ...draft, binding }, this.context().chat[index]!.mes), false);
            this.readyState = true; this.reason = ''; this.checkAlignment();
          } else await this.persist(() => this.runtime.submit(draft.commit.actions.at(-1)!, binding, draft.text, { sourceText: this.context().chat[index]!.mes }));
          this.record('ALREADY_ARCHIVED', '该操作实际已保存，仅响应丢失；已恢复正式结果，不作为本地草稿放弃'); return;
        }
      }
      // Persist first: an unavailable database must not revive a discarded draft on refresh.
      if (this.cache) await this.cache.savePending(this.runtime.sessionId, []);
      this.runtime.discardPending(); this.pendingImportError = undefined; this.record('PENDING_DISCARDED', '已放弃本地待保存操作；正式聊天中的历史不受影响');
    });
  }
  cancelOperator(): void { this.operator?.abort(new Error('用户取消独立操作模型')); this.record('OPERATOR_CANCELLED', '已取消操作模型请求'); }
  refresh(): Promise<void> {
    return this.enqueue(async () => {
      if (this.runtime.pendingCount) fail('PENDING_SAVE', '请先重试或放弃待保存操作');
      const archive = this.nativeHistoryChanged ? this.adapter.loadMemory() : await this.adapter.load(); this.assertBound();
      if (!archive || archive.definitionHash !== this.core.definition.fingerprint) fail('DEFINITION_MISMATCH', '无法用当前定义恢复此聊天');
      for (const message of this.context().chat) {
        const commit = archive.commits[message.extra?.solve?.headId];
        if (commit && commit.textDigest !== await hash(message.mes)) fail('REPLAY_REQUIRED', '消息正文已变化，请使用重放，重新读取不能代替重放');
      }
      const head = this.findParent(this.context().chat.length, archive);
      if (this.nativeHistoryChanged) { await this.adapter.reconcileNativeSave(archive); this.nativeHistoryChanged = false; }
      const next = this.createRuntime(archive, head); await next.ready(); this.assertBound();
      // The replacement has just checked the same shared certificates. Retire
      // the old Runtime without clearing the replacement's verification cache.
      this.runtime.invalidate(false); this.runtime = next; this.readyState = true; this.reason = '';
      await this.syncVariableViews();
      this.record('RESTORE_COMPLETED', '当前选中历史已重新恢复');
    });
  }
  async validateArchive() {
    this.assertBound(); const archive = this.runtime.archive, results = [];
    for (const commitId of new Set(Object.values(archive.heads))) {
      const started = performance.now();
      try { await restore(archive, commitId); results.push({ commitId, valid: true, durationMs: performance.now() - started }); }
      catch (error) { results.push({ commitId, valid: false, durationMs: performance.now() - started, ...describeError(error) }); }
    }
    this.record('ARCHIVE_CHECKED', `已检查 ${results.length} 条历史链`, results.some(r => !r.valid) ? 'error' : 'info'); return results;
  }
  async rebuildCache(): Promise<void> {
    this.assertBound(); if (!this.cache) fail('CACHE_DISABLED', '当前未启用浏览器缓存');
    const archive = this.runtime.archive, head = this.runtime.headId;
    await this.cache.clearSnapshots(); await this.cache.put(archive, head, await restore(archive, head), this.history);
    this.cacheError = undefined; this.record('CACHE_REBUILT', '已重建快照缓存，待保存草稿保留');
  }
  exportDebugReport(options: { includeState?: boolean; includeText?: boolean } = {}) {
    const report: Record<string, unknown> = { exportedAt: new Date().toISOString(), status: this.getStatus(), logs: this.journal.read(),
      performance: { samples: this.getPerformance(), verification: this.getVerificationStats() },
      history: this.getHistory(), messages: this.getMessages().map(({ text, ...meta }) => options.includeText ? { ...meta, text } : meta) };
    if (options.includeState) { try { report.state = this.runtime.getState(); } catch { report.state = null; } }
    return report;
  }
  dispose(): void {
    if (this.disposed) return;
    this.generationEpoch++; this.finalizingGeneration = false; this.releaseGeneration?.();
    this.disposed = true; this.readyState = false; this.reason = '控制器已释放'; this.operator?.abort(); this.adapter.invalidate(); this.runtime?.invalidate();
    this.disposers.splice(0).reverse().forEach(fn => fn()); if (this.ownsCache) this.cache?.close();
    this.record('DISPOSED', this.reason); this.listeners.clear();
  }
}
export async function attachSillyTavern(definition: Definition, context: () => HostContext, options: AttachOptions = {}, fetcher: typeof fetch = fetch): Promise<SillyTavernController> {
  const core = new SolveCore(await compile(definition));
  const controller = new SillyTavernController(core, context, options, fetcher);
  try { return await controller.start(); } catch (error) { controller.dispose(); throw error; }
}
