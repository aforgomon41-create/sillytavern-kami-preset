import { z } from 'zod';
import { assertJson, at, canonical, clone, covered, fail, hash, matches, pointer, safeKey } from './json.js';
import type { CompiledDefinition, Definition, ExecutionContext, Feedback, Json, LogicalState, ModuleSpec, NumericRule } from './types.js';
import { compileGuideRules } from './guides.js';
import { hasInline, isAuthorPrepared } from './inline.js';
import { compileAuthorDefinition } from './authoring.js';
import { copyFacets, describeFacetHooks } from './facets.js';
import { assertUniqueHolds, describeProjection, formulaName } from './features.js';

export function unwrap(schema: any): any {
  for (let i = 0; i < 32; i++) {
    const d = schema?._zod?.def ?? schema?._def;
    if (d?.innerType) schema = d.innerType;
    else if (d?.type === 'lazy') schema = d.getter();
    else if (d?.type === 'pipe') schema = d.in;
    else return schema;
  }
  fail('SCHEMA_DEPTH', 'Schema 包装过深');
}
export function childSchema(schema: any, key: string): any {
  safeKey(key);
  const s = unwrap(schema);
  const d = s?._zod?.def ?? s?._def;
  if (d?.type === 'object') {
    const shape = s.shape ?? d.shape;
    if (!Object.hasOwn(shape, key)) return d.catchall;
    return shape[key];
  }
  if (d?.type === 'record') return d.valueType;
  if (d?.type === 'array') return d.element;
  if (d?.type === 'tuple') return /^(?:0|[1-9]\d*)$/u.test(key) ? d.items[Number(key)] ?? d.rest : undefined;
  if (d?.type === 'intersection') {
    const left = childSchema(d.left, key), right = childSchema(d.right, key);
    return left && right ? z.intersection(left, right) : left ?? right;
  }
  if (d?.type === 'union') {
    // Descend only when exactly one option has this child (e.g. a gauge {value, max} or a text);
    // the enclosing union is still validated as a whole.
    const found = (d.options as any[]).map(option => childSchema(option, key)).filter(Boolean);
    return found.length === 1 ? found[0] : undefined;
  }
  return undefined;
}
export function schemaAt(schema: any, parts: string[]): any {
  for (const key of parts) { schema = childSchema(schema, key); if (!schema) return undefined; }
  return schema;
}
function schemaDescription(schema: any, seen = new Set<any>()): Json {
  if (seen.size > 128) fail('SCHEMA_DEPTH', 'Schema 嵌套超过限制');
  if (seen.has(schema)) fail('SCHEMA_CYCLE', '递归 Schema 需要显式有限状态结构');
  seen.add(schema);
  const d = schema?._zod?.def ?? schema?._def;
  if (!d) fail('INVALID_SCHEMA', '需要有效 Zod Schema');
  const result: Record<string, Json> = { type: String(d.type) };
  if (d.type === 'object') {
    result.fields = Object.fromEntries(Object.entries(schema.shape).map(([k, s]) => { safeKey(k); if (k.includes('.')) fail('INVALID_KEY', '静态字段名禁止点号'); return [k, schemaDescription(s, seen)]; }));
  }
  if (d.type === 'record') { result.key = schemaDescription(d.keyType, seen); result.value = schemaDescription(d.valueType, seen); }
  if (d.type === 'array') result.element = schemaDescription(d.element, seen);
  if (d.type === 'tuple') { result.items = d.items.map((s: any) => schemaDescription(s, seen)); if (d.rest) result.rest = schemaDescription(d.rest, seen); }
  if (d.type === 'intersection') { result.left = schemaDescription(d.left, seen); result.right = schemaDescription(d.right, seen); }
  if (d.innerType) result.inner = schemaDescription(d.innerType, seen);
  if (d.type === 'pipe') { result.input = schemaDescription(d.in, seen); result.output = schemaDescription(d.out, seen); }
  if (d.type === 'lazy') result.inner = schemaDescription(d.getter(), seen);
  if (d.options) result.options = d.options.map((s: any) => schemaDescription(s, seen));
  if (d.values) result.values = [...d.values];
  if (d.entries) result.entries = d.entries;
  if (d.checks) result.checks = d.checks.map((c: any) => {
    const def = c._zod?.def ?? {};
    return Object.fromEntries(Object.entries(def).filter(([, v]) => ['string', 'number', 'boolean'].includes(typeof v))) as Json;
  });
  // Function behavior/dependencies are identified by the author's immutable definition version.
  // Zod exposes defaultValue as a getter, including for callbacks. Never sample it
  // while fingerprinting: doing so would draw random values or run side effects.
  const defaultDescriptor = Object.getOwnPropertyDescriptor(d, 'defaultValue');
  if (defaultDescriptor?.get) result.default = 'runtime-bound-by-definition-version';
  else if (defaultDescriptor?.value !== undefined && typeof defaultDescriptor.value !== 'function') { assertJson(defaultDescriptor.value); result.default = defaultDescriptor.value; }
  seen.delete(schema);
  return result;
}
export async function compile(definition: Definition): Promise<CompiledDefinition> {
  if (!isAuthorPrepared(definition) && (definition.facets?.length || hasInline(definition.schema) || definition.outputSchema && hasInline(definition.outputSchema))) return (await compileAuthorDefinition(definition)).definition;
  return compilePrepared(definition);
}
/** Internal normalized definition compiler; never runs author collectors or notifications. */
export async function compilePrepared(definition: Definition): Promise<CompiledDefinition> {
  if (!definition.id || !definition.version) fail('DEFINITION_VERSION', '作者定义必须有固定 id 与版本');
  if (definition.runtimeBindings !== undefined) assertJson(definition.runtimeBindings);
  const guides = compileGuideRules(definition);
  const facets = definition.facets ? copyFacets(definition.facets) : undefined;
  for (const facet of facets ?? []) {
    const record = definition.runtimeBindings?.authoring?.facets.find(value => value.id === facet.id);
    if (!record || canonical(record) !== canonical({ id: facet.id, version: facet.version, ...(facet.build !== undefined ? { build: facet.build } : {}), ...(facet.dependencies !== undefined ? { dependencies: facet.dependencies } : {}) })) fail('FACET_BINDING', 'Facet版本绑定缺失或变化：' + facet.id);
  }
  const facetRuntime = describeFacetHooks(facets);
  const schemaShape = schemaDescription(definition.schema);
  for (const [name, m] of Object.entries(definition.modules ?? {})) {
    safeKey(name);
    let p: string | undefined = name;
    const seen = new Set<string>();
    while (p) {
      if (seen.has(p)) fail('MODULE_CYCLE', '模块父级不能循环');
      seen.add(p);
      if (!definition.modules?.[p]) fail('MODULE_PARENT', `未知父模块：${p}`);
      p = definition.modules[p]?.parent;
    }
    for (const path of m.paths) path.split('.').forEach(k => { if (k !== '*') safeKey(k); });
  }
  for (const ref of definition.refs ?? []) {
    const allowed = ref.kind === 'single' ? ['null', 'unset', 'restrict'] : ref.kind === 'array' ? ['remove', 'restrict'] : ['unset', 'restrict'];
    if (!allowed.includes(ref.onDelete)) fail('REF_DELETE_POLICY', `${ref.kind} 引用不支持 ${ref.onDelete} 清理策略`);
  }
  const engineRules = describeEngineRules(definition);
  const metadata = { id: definition.id, version: definition.version, schemaShape,
    entities: definition.entities ?? [], refs: definition.refs ?? [], modules: definition.modules ?? {},
    numeric: definition.numeric ?? {}, readonly: definition.readonly ?? [], internal: definition.internal ?? [],
    templates: definition.templates ?? {}, prefabs: definition.prefabs ?? {},
    ...(definition.runtimeBindings !== undefined ? { runtimeBindings: definition.runtimeBindings } : {}),
    // Only present when used, so fingerprints of existing definitions are unchanged.
    ...(engineRules ? { engineRules } : {}) };
  const outputShape = definition.outputSchema ? schemaDescription(definition.outputSchema) : null;
  // The fingerprint pins what decides execution results, so a chat replays the same way forever.
  // Text written for the model (module guides and labels, guides) only shapes prompts: editing it keeps old chats usable.
  const ruleModules = Object.fromEntries(Object.entries(metadata.modules).map(([name, m]) => {
    const { guide: _guide, label: _label, ...rule } = m as ModuleSpec; return [name, rule];
  }));
  const fingerprint = await hash({ ...metadata, modules: ruleModules, outputShape, ...(facetRuntime.length ? { facetRuntime } : {}) });
  const storedSchema = definition.outputSchema ?? storedProjection(definition.schema);
  const fixed = clone(metadata);
  const freeze = (value: any): void => { if (value && typeof value === 'object') { for (const child of Object.values(value)) freeze(child); Object.freeze(value); } };
  freeze(fixed);
  return { ...definition, initialData: clone(definition.initialData), entities: fixed.entities, refs: fixed.refs, modules: fixed.modules,
    numeric: fixed.numeric, readonly: fixed.readonly, internal: fixed.internal, templates: fixed.templates, prefabs: fixed.prefabs,
    ...(fixed.runtimeBindings !== undefined ? { runtimeBindings: fixed.runtimeBindings } : {}),
    views: definition.views ? Object.freeze({ ...definition.views }) : undefined,
    guides: guides.length ? guides : undefined,
    ...(facets ? { facets: Object.freeze(facets) as typeof facets } : {}),
    fingerprint, schemaShape, outputShape, storedSchema, structuralSchema: storedProjection(storedSchema, true) };
}
/** Behavior-relevant engine rules. bgm and display are presentation and stay outside the fingerprint. */
function describeEngineRules(definition: Definition): Json | undefined {
  const keys = (path: string) => path.split('.').forEach(part => { if (part !== '*') safeKey(part); });
  const rules: Record<string, Json> = {};
  if (definition.round !== undefined) {
    keys(definition.round);
    const leaf = unwrap(schemaAt(definition.schema, definition.round.split('.')));
    if (leaf?._zod?.def?.type !== 'number') fail('ROUND_PATH', '轮次路径必须指向数值字段');
    rules.round = definition.round;
  }
  if (definition.stamps && Object.keys(definition.stamps).length) {
    for (const [pattern, rule] of Object.entries(definition.stamps)) { keys(pattern); safeKey(rule.field); safeKey(rule.text); }
    rules.stamps = clone(definition.stamps) as unknown as Json;
  }
  if (definition.lists && Object.keys(definition.lists).length) {
    for (const [pattern, rule] of Object.entries(definition.lists)) {
      keys(pattern);
      if (!Number.isInteger(rule.max) || !Number.isInteger(rule.warn) || rule.max < 1 || rule.warn < 0 || rule.warn > rule.max) fail('LIST_RULE', `清单上限无效：${pattern}`);
    }
    rules.lists = clone(definition.lists) as unknown as Json;
  }
  if (definition.computed && Object.keys(definition.computed).length) {
    rules.computed = Object.fromEntries(Object.entries(definition.computed).map(([pattern, rule]) => { keys(pattern); return [pattern, { label: rule.label, formula: formulaName(rule.formula) }]; }));
  }
  const projection = describeProjection(definition.projection);
  if (projection !== undefined) rules.projection = projection;
  if (definition.groups && Object.keys(definition.groups).length) rules.groups = clone(definition.groups) as unknown as Json;
  if (definition.uniqueHolds?.length) {
    for (const rule of definition.uniqueHolds) { keys(rule.path); safeKey(rule.flag); }
    rules.uniqueHolds = clone(definition.uniqueHolds) as unknown as Json;
  }
  for (const [name, module] of Object.entries(definition.modules ?? {})) if (module.exclusive !== undefined && !module.exclusive) fail('MODULE_EXCLUSIVE', `互斥组名不能为空：${name}`);
  return Object.keys(rules).length ? rules : undefined;
}
// Input effects are one-way and must never run on already stored output.
// A transform's output cannot be inferred from JS; use outputSchema for its constraints.
function storedProjection(schema: any, structuralOnly = false): any {
  const d = schema._zod.def;
  const checks = structuralOnly ? d.checks?.filter((c: any) => c._zod?.def?.check !== 'custom') : d.checks;
  if (d.type === 'transform') return z.unknown();
  if (d.type === 'lazy') return storedProjection(d.getter(), structuralOnly);
  if (d.type === 'pipe') return storedProjection(d.out, structuralOnly);
  if (['default', 'prefault', 'catch', 'readonly'].includes(d.type)) return storedProjection(d.innerType, structuralOnly);
  if (d.innerType) return schema.clone({ ...d, innerType: storedProjection(d.innerType, structuralOnly), ...(checks ? { checks } : {}) });
  if (d.type === 'object') return schema.clone({ ...d, shape: Object.fromEntries(Object.entries(schema.shape).map(([k, s]) => [k, storedProjection(s, structuralOnly)])), ...(checks ? { checks } : {}) });
  if (d.type === 'array') return schema.clone({ ...d, element: storedProjection(d.element, structuralOnly), ...(checks ? { checks } : {}) });
  if (d.type === 'tuple') return schema.clone({ ...d, items: d.items.map((s: any) => storedProjection(s, structuralOnly)), ...(d.rest ? { rest: storedProjection(d.rest, structuralOnly) } : {}), ...(checks ? { checks } : {}) });
  if (d.type === 'intersection') return schema.clone({ ...d, left: storedProjection(d.left, structuralOnly), right: storedProjection(d.right, structuralOnly), ...(checks ? { checks } : {}) });
  if (d.type === 'record') return schema.clone({ ...d, valueType: storedProjection(d.valueType, structuralOnly), ...(checks ? { checks } : {}) });
  if (d.options) return schema.clone({ ...d, options: d.options.map((s: any) => storedProjection(s, structuralOnly)), ...(checks ? { checks } : {}) });
  return checks ? schema.clone({ ...d, checks }) : schema;
}
export function isModuleEnabled(def: CompiledDefinition, state: LogicalState, name: string): boolean {
  const m = def.modules?.[name];
  if (!m || !state.engineState.activeModules[name]) return false;
  return !m.parent || isModuleEnabled(def, state, m.parent);
}
export function dormant(def: CompiledDefinition, state: LogicalState, parts: string[]): boolean {
  return Object.entries(def.modules ?? {}).some(([name, m]) => !isModuleEnabled(def, state, name) && m.paths.some(p => covered(p, parts)));
}
export function numericRule(def: CompiledDefinition, parts: string[]): NumericRule | undefined {
  const schema = unwrap(schemaAt(def.schema, parts));
  const d = schema?._zod?.def;
  let rule: NumericRule | undefined;
  if (d?.type === 'number') {
    rule = {};
    for (const check of d.checks ?? []) {
      const c = check._zod?.def;
      if (c?.check === 'greater_than' && c.inclusive) rule.min = Math.max(rule.min ?? -Infinity, c.value);
      if (c?.check === 'less_than' && c.inclusive) rule.max = Math.min(rule.max ?? Infinity, c.value);
      if (c?.check === 'number_format' && String(c.format).includes('int')) rule.integer = true;
    }
  }
  for (const [pattern, extra] of Object.entries(def.numeric ?? {})) if (matches(pattern, parts)) rule = { ...rule, ...extra };
  return rule;
}
export function clamp(def: CompiledDefinition, parts: string[], value: unknown, strict: boolean, feedback: Feedback[]): unknown {
  const rule = numericRule(def, parts);
  if (!rule || typeof value !== 'number') return value;
  if (!Number.isFinite(value)) fail('INVALID_NUMBER', '数值必须有限', pointer(parts));
  const next = Math.min(rule.max ?? Infinity, Math.max(rule.min ?? -Infinity, value));
  if (rule.integer && !Number.isInteger(value)) fail('INTEGER_REQUIRED', '目标需要整数', pointer(parts));
  if (next !== value) {
    if (strict) fail('BOUND_VIOLATION', '原子操作数值超出上下限', pointer(parts));
    feedback.push({ level: 'L1', code: 'CLAMP_APPLIED', message: `${value} 调整为 ${next}`, path: pointer(parts) });
  }
  return next;
}
// Validate stored output without re-running input transforms/default generators.
// Zod's output projection keeps structural/refinement checks and removes transforms.
export async function validateStored(def: CompiledDefinition, state: LogicalState, context: ExecutionContext, structuralOnly = false): Promise<void> {
  assertJson(state);
  const output = structuralOnly ? def.structuralSchema : def.storedSchema;
  const result = await output.safeParseAsync(state.data);
  if (!result.success) {
    const activeIssues = result.error.issues.filter((issue: any) => !dormant(def, state, issue.path.map(String)));
    if (activeIssues.length) fail('SCHEMA_REJECTED', activeIssues.map((i: any) => `${i.path.join('.')}: ${i.message}`).join('; '));
  } else if (canonical(result.data) !== canonical(state.data)) fail('STORED_STATE_CHANGED', '状态含未声明字段或需要再次转换的值');
  if (!structuralOnly) { assertUniqueHolds(def, state); await def.validateState?.(clone(state), clone(context)); }
}
function normalizeInput(def: CompiledDefinition, state: LogicalState, parts: string[], input: any, strict: boolean, feedback: Feedback[], allowDormant: boolean): any {
  if (input === undefined) return undefined;
  if (!allowDormant && dormant(def, state, parts)) fail('MODULE_DORMANT', '操作中包含休眠字段', pointer(parts));
  if (typeof input === 'number') return clamp(def, parts, input, strict, feedback);
  if (!input || typeof input !== 'object') return input;
  const schema = unwrap(schemaAt(def.schema, parts));
  if (Array.isArray(input)) return input.map((v, i) => normalizeInput(def, state, [...parts, String(i)], v, strict, feedback, allowDormant));
  const result: any = {}, d = schema?._zod?.def;
  for (const [rawKey, value] of Object.entries(input)) {
    safeKey(rawKey);
    const key = d?.type === 'record' ? rawKey.replace(/\./gu, '_') : rawKey;
    if (key !== rawKey) feedback.push({ level: 'L1', code: 'KEY_SANITIZED', message: `${rawKey} → ${key}` });
    if (Object.hasOwn(result, key) || (key !== rawKey && Object.hasOwn(input, key))) fail('KEY_COLLISION', '动态键净化后重名', pointer([...parts, key]));
    if (d?.type === 'object' && !Object.hasOwn(schema.shape, key) && !d.catchall) fail('SCHEMA_PATH', '输入包含未声明字段', pointer([...parts, key]));
    result[key] = normalizeInput(def, state, [...parts, key], value, strict, feedback, allowDormant);
  }
  return result;
}
function missingDormant(def: CompiledDefinition, state: LogicalState, parts: string[], input: any): boolean {
  if (input === undefined) return dormant(def, state, parts);
  if (!input || typeof input !== 'object') return false;
  const schema = unwrap(schemaAt(def.schema, parts));
  const keys = new Set([...Object.keys(input), ...Object.keys(schema?.shape ?? {})]);
  return [...keys].some(key => missingDormant(def, state, [...parts, key], input[key]));
}
export async function parseInput(def: CompiledDefinition, state: LogicalState, parts: string[], input: unknown, strict: boolean, feedback: Feedback[], allowDormant = false): Promise<any> {
  const schema = schemaAt(def.schema, parts);
  if (!schema) fail('SCHEMA_PATH', '目标不在 Schema 中或需要修改完整联合类型字段', pointer(parts));
  const value = normalizeInput(def, state, parts, input, strict, feedback, allowDormant);
  // Avoid running transforms/default functions once in a failed whole-object parse
  // and a second time in a dormant-field fallback.
  if (value && typeof value === 'object' && !Array.isArray(value) && missingDormant(def, state, parts, value)) {
    const parsed: any = {};
    const shape = unwrap(schema)?.shape;
    for (const key of new Set([...Object.keys(value), ...Object.keys(shape ?? {})])) {
      const path = [...parts, key];
      if (dormant(def, state, path) && !Object.hasOwn(value, key)) continue;
      const v = await parseInput(def, state, path, (value as any)[key], strict, feedback, allowDormant);
      if (v !== undefined) parsed[key] = v;
    }
    return parsed;
  }
  const result = await schema.safeParseAsync(value);
  if (!result.success) {
    const activeIssues = result.error.issues.filter((issue: any) => !dormant(def, state, [...parts, ...issue.path.map(String)]));
    if (activeIssues.length) fail('SCHEMA_REJECTED', activeIssues.map((i: any) => i.message).join('; '), pointer(parts));
    // A module can omit inactive required fields. Parse present active children separately.
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const parsed: any = {};
      const shape = unwrap(schema)?.shape;
      for (const key of new Set([...Object.keys(value), ...Object.keys(shape ?? {})])) {
        const path = [...parts, key];
        if (dormant(def, state, path) && !Object.hasOwn(value, key)) continue;
        const v = await parseInput(def, state, path, (value as any)[key], strict, feedback, allowDormant);
        if (v !== undefined) parsed[key] = v;
      }
      return parsed;
    }
    fail('SCHEMA_REJECTED', result.error.message, pointer(parts));
  }
  if (result.data !== undefined) assertJson(result.data);
  return result.data;
}
export async function initialState(def: CompiledDefinition, initial: unknown = def.initialData): Promise<LogicalState> {
  const state: LogicalState = { data: {}, engineState: {
    activeModules: Object.fromEntries(Object.entries(def.modules ?? {}).map(([k, m]) => [k, m.enabled !== false])),
    prefabLifecycle: Object.fromEntries(Object.keys(def.prefabs ?? {}).map(k => [k, 'dormant' as const]))
  } };
  const parsed = await parseInput(def, state, [], initial, false, [], true);
  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') fail('STATE_ROOT', '状态根必须是对象');
  state.data = parsed;
  await validateStored(def, state, {});
  return state;
}
