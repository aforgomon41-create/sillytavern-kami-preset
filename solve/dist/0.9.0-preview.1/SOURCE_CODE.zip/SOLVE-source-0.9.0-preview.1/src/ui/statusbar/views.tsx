/**
 * Status bar: a floating launcher that shows a one-line overview bar while there is data (a round
 * button otherwise); clicking it expands the panel, and the overview bar becomes the panel title.
 * Panel tabs come from the declared layout: player sheet, collapsible entity lists with a
 * relationship graph, and a force-directed map.
 */
import * as React from 'react';
import { useKit } from '../kit.js';
import { artOf, isEmpty, StatusModel, thumbOf, type Path } from './model.js';
import { ModelContext, NavigateContext, RefChip, Section, useModel } from './fields.js';
import { EntityBody, PageBody, Pages, resolveUser, visible, type PageSpec } from './body.js';
import { GraphView, type GraphEdge, type GraphGroup, type GraphNode, type Tone } from './graph.js';
import { PlayerSheet, type SheetItem } from './sheet.js';
import { Codex, type CodexCategory } from './codex.js';
import { Art, Mono, Spoiler, part, solve, useWide } from './widgets.js';
import { ActionBar, CreateForm, InteractLayer, PendingNarration, editFor, useInteract, type Interact } from './interact.js';
import { SettingsBody, type SettingsHost } from './settings.js';

export interface BgmView { title?: string; source: string; playing: boolean; enabled: boolean; volume: number; onToggle(v: boolean): void; onVolume(v: number): void }
export interface StatusBarProps {
  model: StatusModel; bgm?: BgmView;
  /** Last open tab; the host persists it through onTabChange. */
  defaultTab?: string; onTabChange?: (tab: string) => void;
  /** Starting state of the launcher (the host restores the last one). */
  defaultMode?: Mode; onModeChange?: (mode: Mode) => void;
  /** Saved launcher position; the host persists it. */
  position?: { x: number; y: number }; onPositionChange?: (p: { x: number; y: number }) => void;
  /** Player interactions declared in the structure (edit / actions); omitted → read-only. */
  interact?: Interact;
  /** Player settings (⚙ in the panel); omitted → no settings button. */
  settings?: SettingsHost;
  /** Open the panel on the settings page (the host restores it). */
  defaultSettings?: boolean;
}
export type Mode = 'bar' | 'dot' | 'panel';
const rel = (s: string): Path => s.split('.');

export function StatusBar({ model, bgm, defaultTab, onTabChange, defaultMode = 'bar', onModeChange, position, onPositionChange, interact, settings, defaultSettings }: StatusBarProps) {
  const K = useKit();
  const tabs = model.layout.filter((t: any) => model.moduleOn(t.module));
  const [tab, setTabState] = React.useState<string>(tabs.some((t: any) => t.tab === defaultTab) ? defaultTab! : tabs[0]?.tab ?? '');
  const setTab = (t: string) => { setTabState(t); onTabChange?.(t); };
  const [focus, setFocus] = React.useState<{ path: Path; at: number } | undefined>();
  const hasData = barItems(model).length > 0;
  const [mode, setModeState] = React.useState<Mode>(defaultMode);
  const [rest, setRest] = React.useState<'bar' | 'dot'>(defaultMode === 'dot' ? 'dot' : 'bar');
  const setMode = (next: Mode) => { setModeState(next); if (next !== 'panel') setRest(next); onModeChange?.(next); };
  const anchor = React.useRef<DOMRect | null>(null);
  // The launcher unmounts while the panel is open, so its position lives here and survives folding.
  const [pos, setPos] = React.useState(position);
  const [setup, setSetup] = React.useState(!!defaultSettings);
  const navigate = React.useCallback((path: Path) => {
    const key = path.join('.');
    const hit = (item: any) => {
      if (item.sheet) return key === [item.sheet, item.id === '$user' ? model.userId : item.id].join('.');
      if (item.codex) return (item.codex as CodexCategory[]).some(c => c.collection && key.startsWith(c.collection + '.'));
      const base = item.list ?? item.map ?? item.graph;
      return typeof base === 'string' && key.startsWith(base + '.') && !(item.exclude === '$user' && path[rel(base).length] === model.userId) && !item.graph;
    };
    const target = tabs.find((t: any) => t.items.some(hit));
    if (target) { setTabState(target.tab); onTabChange?.(target.tab); setFocus({ path, at: Date.now() }); setModeState('panel'); setSetup(false); }
  }, [tabs, model]); // eslint-disable-line react-hooks/exhaustive-deps

  const content = (
    <K.TooltipProvider>
      {mode === 'panel' ? (
        <K.Panel title={<Overview model={model} where="title" />} onClose={() => setMode(rest)} closeLabel="收起"
          geometry={panelGeometry(anchor.current)} defaultSize={panelSize()}
          actions={bgm || settings ? <>{bgm ? <BgmButton bgm={bgm} /> : null}{settings ? <SettingsButton open={setup} onToggle={() => setSetup(v => !v)} /> : null}</> : undefined}
          footer={interact?.pending?.length ? <PendingNarration host={interact} /> : undefined}>
          {setup && settings ? <SettingsBody host={settings} {...(bgm ? { bgm } : {})} onBack={() => setSetup(false)} />
            : <PanelBody tabs={tabs} tab={tab} setTab={setTab} focus={focus} />}
        </K.Panel>
      ) : (
        <Launcher mode={hasData ? rest : 'dot'} canBar={hasData} pos={pos} onMove={setPos} onMoved={p => onPositionChange?.(p)}
          onOpen={rect => { anchor.current = rect; setMode('panel'); }} onMode={setMode} />
      )}
    </K.TooltipProvider>
  );
  return <ModelContext.Provider value={model}><NavigateContext.Provider value={navigate}><InteractLayer {...(interact ? { host: interact } : {})}>{content}</InteractLayer></NavigateContext.Provider></ModelContext.Provider>;
}
/**
 * The panel's contents inline (no launcher, no floating window): the structure builder previews a draft layout with it.
 * `tab` follows the builder's selection; interactions go to the given host (the builder's dry run).
 */
export function StatusPreview({ model, tab, onTab, interact }: { model: StatusModel; tab?: string; onTab?: (tab: string) => void; interact?: Interact }) {
  const K = useKit();
  const tabs = model.layout.filter((t: any) => model.moduleOn(t.module));
  const [own, setOwn] = React.useState<string>(tabs[0]?.tab ?? '');
  const current = tab && tabs.some((t: any) => t.tab === tab) ? tab : own;
  const setTab = (t: string) => { setOwn(t); onTab?.(t); };
  return (
    <ModelContext.Provider value={model}><NavigateContext.Provider value={() => undefined}><InteractLayer {...(interact ? { host: interact } : {})}>
      <K.TooltipProvider>
        <div {...solve('status-preview')}>
          <div {...part('title')}><Overview model={model} where="title" /></div>
          <PanelBody tabs={tabs} tab={current} setTab={setTab} focus={undefined} />
          {interact?.pending?.length ? <PendingNarration host={interact} /> : null}
        </div>
      </K.TooltipProvider>
    </InteractLayer></NavigateContext.Provider></ModelContext.Provider>
  );
}
/** The panel's main sections: a sidebar on PC, scrolling tabs on phones (same declaration). */
function PanelBody({ tabs, tab, setTab, focus }: { tabs: any[]; tab: string; setTab: (t: string) => void; focus: Focus }) {
  const m = useModel(), K = useKit();
  const [box, wide] = useWide(900);
  const body = (t: any) => <div {...solve('tab')}>{t.items.filter((i: any) => typeof i === 'string' || m.moduleOn(i.module)).map((item: any, i: number) => <LayoutItem key={i} item={item} focus={focus} />)}</div>;
  const current = tabs.find((t: any) => t.tab === tab) ?? tabs[0];
  return (
    <div ref={box} {...solve('panel-body', { layout: wide ? 'sidebar' : 'tabs' })}>
      {wide ? (
        <>
          <div {...part('nav')}><K.NavList layout="sidebar" label="状态栏" current={current?.tab} onSelect={setTab} items={tabs.map((t: any) => ({ id: t.tab, label: t.tab }))} /></div>
          <div {...part('main')} role="region" aria-label={current?.tab}>{current ? <React.Fragment key={current.tab}>{body(current)}</React.Fragment> : null}</div>
        </>
      ) : (
        <K.Tabs label="状态栏" mode="scroll" sticky swipe value={tab} onValueChange={setTab}
          items={tabs.map((t: any) => ({ value: t.tab, label: t.tab, content: body(t) }))} />
      )}
    </div>
  );
}
/** Desktop: the panel opens where the bar was, so the bar visibly turns into the title. */
/** PC: a roomy panel (lists become list + detail at this width), centred on the bar it opened from. */
const PANEL_MAX = { w: 1180, h: 900 };
export function panelSize(): { w: number; h: number } {
  if (typeof window === 'undefined') return { w: 780, h: 720 };
  return { w: Math.max(780, Math.min(PANEL_MAX.w, window.innerWidth - 64)), h: Math.max(560, Math.min(PANEL_MAX.h, window.innerHeight - 48)) };
}
function panelGeometry(r: DOMRect | null): { x: number; y: number; w: number; h: number } | undefined {
  if (typeof window === 'undefined' || window.innerWidth <= 1000) return undefined;
  const { w, h } = panelSize();
  const cx = r ? r.left + r.width / 2 : window.innerWidth / 2;
  const x = Math.min(Math.max(8, cx - w / 2), window.innerWidth - w - 8);
  const y = r ? Math.max(8, Math.min(r.top, window.innerHeight - h - 8)) : Math.max(8, (window.innerHeight - h) / 2);
  return { x, y, w, h: Math.min(h, window.innerHeight - y - 8) };
}

/* ───────── launcher (floating bar / round button) ───────── */
type Pos = { x: number; y: number };
function Launcher({ mode, canBar, pos, onMove, onMoved, onOpen, onMode }: {
  mode: 'bar' | 'dot'; canBar: boolean; pos?: Pos; onMove: (p: Pos) => void; onMoved: (p: Pos) => void;
  onOpen: (rect: DOMRect) => void; onMode: (m: Mode) => void;
}) {
  const m = useModel();
  const ref = React.useRef<HTMLDivElement>(null);
  const setPos = onMove;
  // Keep the saved spot on screen: after mounting, switching bar ↔ button, or resizing the window.
  React.useLayoutEffect(() => {
    const fit = () => {
      const el = ref.current; if (!el || !pos) return;
      const r = el.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
      const x = Math.min(Math.max(4, pos.x), Math.max(4, vw - r.width - 4)), y = Math.min(Math.max(4, pos.y), Math.max(4, vh - r.height - 4));
      if (x !== pos.x || y !== pos.y) setPos({ x, y });
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [pos, mode]); // eslint-disable-line react-hooks/exhaustive-deps
  const drag = React.useRef<{ x: number; y: number; left: number; top: number; moved: boolean } | null>(null);
  const down = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('[data-solve-part="shrink"]')) return;
    const r = ref.current!.getBoundingClientRect();
    drag.current = { x: e.clientX, y: e.clientY, left: r.left, top: r.top, moved: false };
    ref.current!.setPointerCapture?.(e.pointerId);
  };
  const move = (e: React.PointerEvent) => {
    const d = drag.current; if (!d) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) < 6) return;
    d.moved = true;
    const r = ref.current!.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
    setPos({ x: Math.min(Math.max(4, d.left + dx), vw - r.width - 4), y: Math.min(Math.max(4, d.top + dy), vh - r.height - 4) });
  };
  const up = () => {
    const d = drag.current; drag.current = null;
    if (!d) return;
    if (d.moved) { if (pos) onMoved(pos); return; }
    onOpen(ref.current!.getBoundingClientRect());
  };
  const style = pos ? { left: pos.x, top: pos.y, right: 'auto', bottom: 'auto', transform: 'none' } as React.CSSProperties : undefined;
  return (
    <div ref={ref} {...solve('launcher', { mode, placed: pos ? '' : undefined })} style={style}
      onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={() => { drag.current = null; }}>
      {mode === 'bar' ? (
        <div {...solve('bar')} data-k-level="surface-1" role="button" tabIndex={0} aria-label="展开状态栏" title="点击展开 · 按住拖动"
          onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(ref.current!.getBoundingClientRect()); } }}>
          <Overview model={m} where="bar" />
          <span {...part('open')} aria-hidden="true">▾</span>
          <button type="button" {...part('shrink')} aria-label="收起为按钮" title="收起为按钮" onClick={e => { e.stopPropagation(); onMode('dot'); }}>‹</button>
        </div>
      ) : (
        <>
          <button type="button" {...solve('dot')} aria-label="展开状态栏"
            onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(ref.current!.getBoundingClientRect()); } }}>
            <span aria-hidden="true">◈</span>
          </button>
          {canBar ? <button type="button" {...part('shrink')} data-dir="expand" aria-label="展开为概览横条" title="展开为概览横条" onClick={e => { e.stopPropagation(); onMode('bar'); }}>›</button> : null}
        </>
      )}
    </div>
  );
}

/* ───────── overview (bar content and panel title) ───────── */
interface BarItem { path: string; as?: string; limit?: number; label?: string }
function barItems(m: StatusModel): BarItem[] {
  const raw = ((m.def.display as any)?.bar ?? []) as (string | BarItem)[];
  return raw.map(i => typeof i === 'string' ? { path: i } : i).filter(i => {
    const p = resolve(m, i.path);
    return p && m.meta(p) && !m.dormant(p) && !isEmpty(m.value(p));
  });
}
function resolve(m: StatusModel, s: string): Path | undefined {
  const out = rel(s).map(k => k === '$user' ? m.userId ?? '' : k);
  return out.includes('') ? undefined : out;
}
function Overview({ model: m, where }: { model: StatusModel; where: 'bar' | 'title' }) {
  const round = m.def.round ? m.value(rel(m.def.round)) : undefined;
  return (
    <span {...solve('overview', { where })}>
      {barItems(m).map(item => <BarPiece key={item.path} item={item} path={resolve(m, item.path)!} where={where} />)}
      {typeof round === 'number' ? <span {...part('round')}>第 {round} 轮</span> : null}
    </span>
  );
}
function BarPiece({ item, path, where }: { item: BarItem; path: Path; where: 'bar' | 'title' }) {
  const m = useModel(), value = m.value(path), meta = m.meta(path);
  if (meta?.type === 'ref') {
    const chain: string[] = [];
    for (let c: any = value, n = 0; typeof c === 'string' && n < 8; n++) { chain.unshift(m.entityName(c)); const p = m.locate(c); c = p ? m.value(p)?.parent : undefined; }
    return <span {...part('place')}>{chain.slice(-2).join(' › ')}</span>;
  }
  if (m.widget(path) === 'datetime' || item.as === 'datetime') return <span {...part('time')}>{formatTime(value, true)}</span>;
  if (meta?.type === 'record' && Object.values(value).every((g: any) => typeof g?.value === 'number' && typeof g?.max === 'number')) {
    return <span {...part('vitals')}>{Object.entries(value).slice(0, item.limit ?? 3).map(([k, g]: any, i) => (
      <span key={k} {...part('vital')} data-slot={i % 4} title={`${k} ${g.value}/${g.max}`}>
        <span {...part('label')}>{k}</span><span {...part('track')}><i style={{ width: `${Math.max(0, Math.min(1, g.value / g.max)) * 100}%` }} /></span><span {...part('value')}>{g.value}</span>
      </span>))}</span>;
  }
  if (meta?.type === 'refs') return <People ids={value as string[]} label={m.label(path)} where={where} />;
  return <span {...part('chip')} title={m.label(path)}>{String(value)}</span>;
}
/** Present characters as avatars; in the panel title each one opens that character. */
function People({ ids, label, where }: { ids: string[]; label: string; where: 'bar' | 'title' }) {
  const m = useModel(), go = React.useContext(NavigateContext);
  const names = ids.map(id => m.entityName(id));
  const shown = ids.slice(0, where === 'title' ? 6 : 4);
  return (
    <span {...part('people')} title={`${label}：${names.join('、')}`} aria-label={`${label}：${names.join('、')}`}>
      {shown.map(id => where === 'title'
        ? <button key={id} type="button" onClick={() => { const p = m.locate(id); if (p) go(p); }} aria-label={`查看${m.entityName(id)}`} title={m.entityName(id)}><Mono name={m.entityName(id)} src={m.picture(id)} /></button>
        : <i key={id}><Mono name={m.entityName(id)} src={m.picture(id)} /></i>)}
      {ids.length > shown.length ? <small>+{ids.length - shown.length}</small> : null}
    </span>
  );
}
function formatTime(t: any, short = false): string {
  if (!t || typeof t !== 'object') return '';
  const date = [!short && t.year !== undefined ? `${t.year}年` : '', t.month !== undefined ? `${t.month}月` : '', t.day !== undefined ? `${t.day}日` : ''].join('');
  return [short ? '' : t.era, date, t.clock].filter(Boolean).join(' ');
}

/* ───────── layout items ───────── */
type Focus = { path: Path; at: number } | undefined;
function LayoutItem({ item, focus }: { item: any; focus: Focus }) {
  if (typeof item === 'string') return <Section path={rel(item)} />;
  if (item.sheet) return <PlayerSheet item={item as SheetItem} />;
  if (item.codex) return <Codex categories={item.codex as CodexCategory[]} {...(focus ? { focus } : {})} />;
  if (item.map) return <MapItem item={item} focus={focus} />;
  if (item.graph) return <RelationGraph item={item} />;
  if (item.list) return <CollapseList item={item} focus={focus} />;
  if (item.path) return <Section path={rel(item.path)} />;
  return null;
}

/** Entities as collapsed cards; present ones first, then by the declared order of `order` (an enum). */
/**
 * An entity list, declared once and laid out per width:
 *   · narrow (phones): an accordion, each card opens in place;
 *   · wide (PC): an index on the left and the opened entry on the right (`wide: 'stack'` keeps the accordion).
 * `group: '<enum field>'` adds category chips and section headers in both layouts.
 */
function CollapseList({ item, focus }: { item: any; focus: Focus }) {
  const m = useModel(), K = useKit();
  const path = rel(item.list), value: Record<string, any> = m.value(path) ?? {};
  const [box, roomy] = useWide(860);
  const split = roomy && item.wide !== 'stack';
  const present = new Set<string>(item.present ? m.value(rel(item.present)) ?? [] : []);
  const orderMeta = item.order ? m.meta([...path, '*', item.order]) : undefined;
  const rank = (id: string) => orderMeta?.values ? orderMeta.values.indexOf(value[id]?.[item.order]) : 0;
  const all = Object.keys(value).filter(id => !(item.exclude === '$user' && id === m.userId))
    .sort((a, b) => Number(present.has(b)) - Number(present.has(a)) || rank(a) - rank(b));
  const here = all.filter(id => present.has(id));
  const [only, setOnly] = React.useState<'all' | 'present'>('all');
  const [query, setQuery] = React.useState('');
  // Categories: the declared enum's values in order, only those in use.
  const groupMeta = item.group ? m.meta([...path, '*', item.group]) : undefined;
  const groupOf = (id: string): string => String(value[id]?.[item.group] ?? '其他');
  const groups = item.group ? [...(groupMeta?.values ?? []), '其他'].filter(g => all.some(id => groupOf(id) === g)) : [];
  const [cat, setCat] = React.useState<string>('');
  // Search by name, alias and the short tags/labels a reader would remember someone by.
  const words = (id: string) => [value[id]?.name, value[id]?.title, value[id]?.content, value[id]?.alias, ...(Array.isArray(value[id]?.tags) ? value[id].tags : []), ...(item.badges ?? []).map((b: string) => value[id]?.[b])]
    .filter(x => typeof x === 'string').join(' ').toLowerCase();
  const q = query.trim().toLowerCase();
  const ids = (only === 'present' ? here : all)
    .filter(id => !cat || groupOf(id) === cat)
    .filter(id => !q || (m.spoiler([...path, id]) !== 'spoiler' && (words(id).includes(q) || id.toLowerCase().includes(q))));
  const [open, setOpen] = React.useState<Set<string>>(new Set());
  const [sel, setSel] = React.useState<string | undefined>();
  const refs = React.useRef(new Map<string, HTMLElement>());
  React.useEffect(() => {
    if (!focus || focus.path.slice(0, path.length).join('.') !== path.join('.')) return;
    const id = focus.path[path.length]; if (!id || !value[id]) return;
    setOnly('all'); setCat(''); setQuery(''); setOpen(s => new Set(s).add(id)); setSel(id);
    requestAnimationFrame(() => refs.current.get(id)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
  }, [focus]); // eslint-disable-line react-hooks/exhaustive-deps
  const title = item.title ?? m.label(path);
  if (!all.length) return <div ref={box}><CreateForm path={path} /><K.Empty title={`还没有${title}`} /></div>;

  // What a row shows; an entry the player doesn't know keeps its name to itself (the badges still say what kind of thing it is).
  const head = (id: string, inRow = false) => {
    const veiled = m.spoiler([...path, id]) === 'spoiler';
    const v = veiled ? { ...(value[id] ?? {}), name: '？？？', title: undefined, thumb: undefined, image: undefined } : value[id] ?? {};
    const score = item.score ? resolve(m, item.score) : undefined;
    const s = score ? m.value([...path, id, ...score]) : undefined, sMeta = score ? m.meta([...path, id, ...score]) : undefined;
    return {
      name: <span {...solve('entity-head')}><span {...part('avatar')} aria-hidden="true"><Mono name={v.name ?? v.title ?? id} src={thumbOf(v)} /></span><span {...part('name')}>{v.name ?? v.title ?? id}{v.alias ? <small>「{v.alias}」</small> : null}</span></span>,
      meta: <span {...solve('entity-meta')}>
        {present.has(id) ? <K.Badge tone="success">在场</K.Badge> : null}
        {(item.badges ?? []).filter((b: string) => !(inRow && groups.length && b === item.group)).map((b: string) => v[b] ? <K.Badge key={b} tone="neutral">{String(v[b])}</K.Badge> : null)}
        {typeof s === 'number' ? <span {...part('score')} data-sign={s > 0 ? 'positive' : s < 0 ? 'negative' : 'zero'} title={`${item.scoreLabel ?? sMeta?.desc ?? ''}`}>{item.scoreLabel ?? ''} {s > 0 ? '+' : ''}{s}</span> : null}
      </span>,
    };
  };
  // Section headers when browsing every category.
  const sections: { label?: string; ids: string[] }[] = groups.length && !cat ? groups.map(g => ({ label: g, ids: ids.filter(id => groupOf(id) === g) })).filter(x => x.ids.length) : [{ ids }];
  const toolbar = (
    <>
      <div {...solve('list-head')}>
        <h4 {...part('title')}>{title}<small>{all.length}</small></h4>
        {here.length && here.length < all.length && K.Segmented ? <K.Segmented size="sm" label="筛选" value={only} onValueChange={v => setOnly(v as 'all' | 'present')}
          options={[{ value: 'all', label: `全部 ${all.length}` }, { value: 'present', label: `在场 ${here.length}` }]} /> : null}
        {item.search ? <input type="search" {...solve('search')} value={query} onChange={e => setQuery(e.target.value)} placeholder={`搜索${title}`} aria-label={`搜索${title}`} /> : null}
      </div>
      {groups.length > 1 ? (
        <div {...solve('cats')} role="group" aria-label={`${title}分类`}>
          {['', ...groups].map(g => (
            <button key={g || '*'} type="button" {...solve('cat')} aria-pressed={cat === g} onClick={() => setCat(g)}>
              {g || '全部'}<small>{g ? all.filter(id => groupOf(id) === g).length : all.length}</small>
            </button>
          ))}
        </div>
      ) : null}
      <CreateForm path={path} />
      {q && !ids.length ? <span {...solve('none')}>没有找到「{query.trim()}」</span> : null}
    </>
  );

  if (split) {
    const current = ids.includes(sel ?? '') ? sel! : ids[0];
    const h = current ? head(current) : undefined;
    return (
      <section ref={box} {...solve('group', { layout: 'split' })}>
        {toolbar}
        <div {...solve('master')}>
          <nav {...part('index')} aria-label={title}>
            {sections.map(sec => (
              <React.Fragment key={sec.label ?? '*'}>
                {sec.label ? <h5 {...part('section')}>{sec.label}<small>{sec.ids.length}</small></h5> : null}
                {sec.ids.map(id => { const r = head(id, true); return (
                  <button key={id} ref={el => { if (el) refs.current.set(id, el); else refs.current.delete(id); }} type="button" {...solve('index-row', { present: present.has(id) ? '' : undefined })}
                    aria-current={id === current ? 'true' : undefined} onClick={() => setSel(id)}>{r.name}{r.meta}</button>
                ); })}
              </React.Fragment>
            ))}
          </nav>
          <article {...part('detail')} aria-live="polite">
            {current && h ? (
              <>
                <header {...part('head')}>{h.name}{h.meta}</header>
                <CardBody key={current} item={item} path={[...path, current]} v={value[current] ?? {}} />
              </>
            ) : <div {...part('placeholder')}>没有符合条件的{title}</div>}
          </article>
        </div>
      </section>
    );
  }
  return (
    <section ref={box} {...solve('group')}>
      {toolbar}
      {sections.map(sec => (
        <React.Fragment key={sec.label ?? '*'}>
          {sec.label ? <h5 {...solve('list-section')}>{sec.label}<small>{sec.ids.length}</small></h5> : null}
          <div {...solve('stack')}>
            {sec.ids.map(id => { const r = head(id, true); return (
              <div key={id} ref={el => { if (el) refs.current.set(id, el); else refs.current.delete(id); }} {...solve('entity-row', { present: present.has(id) ? '' : undefined })}>
                <K.CollapseCard open={open.has(id)} onOpenChange={o => setOpen(prev => { const n = new Set(prev); if (o) n.add(id); else n.delete(id); return n; })} title={r.name} meta={r.meta}>
                  {open.has(id) ? <CardBody item={item} path={[...path, id]} v={value[id] ?? {}} /> : null}
                </K.CollapseCard>
              </div>
            ); })}
          </div>
        </React.Fragment>
      ))}
    </section>
  );
}

/** What is kept in this entity (a building): every holder's `<field>.<id>` under the holdings pattern, e.g. characters.*.items. */
function StoredHere({ id, spec }: { id: string; spec: { holders: string; field: string } }) {
  const m = useModel();
  const [owners, , ...rest] = spec.holders.split('.');
  const rows: { who: string; item: string; n: number }[] = [];
  for (const who of Object.keys(m.value([owners!]) ?? {})) {
    const held: Record<string, any> = m.value([owners!, who, ...rest]) ?? {};
    for (const [item, own] of Object.entries(held)) { const n = own?.[spec.field]?.[id]; if (typeof n === 'number' && n > 0) rows.push({ who, item, n }); }
  }
  if (!rows.length || m.dormant([owners!, Object.keys(m.value([owners!]) ?? {})[0] ?? '', ...rest])) return null;
  return (
    <section {...solve('stored-here')}>
      <h5 {...part('title')}>存放的物品<small>{rows.length}</small></h5>
      <ul>{rows.map(r => <li key={r.who + r.item}><RefChip id={r.who} /><span {...part('item')}><span {...part('glyph')} aria-hidden="true"><Mono name={m.entityName(r.item)} src={m.picture(r.item)} /></span>{m.entityName(r.item)}</span><b>×{r.n.toLocaleString('zh-CN')}</b></li>)}</ul>
    </section>
  );
}

/**
 * An opened card. `aside` (the overview) sits under the picture in a left column on wide screens, like the
 * player sheet; on narrow ones it becomes the first page.
 */
function CardBody({ item, path, v }: { item: any; path: Path; v: any }) {
  const m = useModel();
  const [ref, wide] = useWide(560);
  const id = path.at(-1)!, name = v.name ?? v.title ?? id;
  const aside: { label: string; paths: string[] } | undefined = item.aside;
  const asideShown = !!aside && aside.paths.some(r => visible(m, resolveUser(m, path, r)));
  const pages: PageSpec[] | undefined = item.pages ? (aside && !wide ? [{ label: aside.label, paths: aside.paths }, ...item.pages] : item.pages) : undefined;
  const side = wide && (artOf(v) || asideShown);
  // An entry the player does not know yet (a secret) opens as one spoiler.
  const veiled = m.spoiler(path) === 'spoiler';
  // The name is in the header already — unless the header is veiled, or the player may rename it here.
  const live = useInteract();
  const skip = [...(item.badges ?? []), ...(item.hide ?? []), ...['name', 'title'].filter(k => !veiled && !(live && editFor(m, [...path, k])))];
  const body = (
    <div ref={ref} {...solve('card-body', { art: artOf(v) ? '' : undefined, aside: wide && asideShown ? '' : undefined })}><div {...part('layout')}>
      {side ? (
        <div {...part('side')}>
          {artOf(v) ? <Art src={artOf(v)!} alt={name} variant="side" /> : null}
          {aside && asideShown ? <div {...part('overview')}><PageBody base={path} paths={aside.paths} /></div> : null}
        </div>
      ) : artOf(v) ? <Art src={artOf(v)!} alt={name} variant="side" /> : null}
      <div {...part('main')}>{pages ? <Pages key={wide ? 'wide' : 'narrow'} base={path} pages={pages} label={`${name}的资料`} compact />
        : <EntityBody path={path} skip={skip} />}
        {item.stored ? <StoredHere id={id} spec={item.stored} /> : null}
        {item.backrefs ? <Backrefs id={id} specs={item.backrefs} /> : null}
        <ActionBar path={path} /></div>
    </div></div>
  );
  return veiled ? <Spoiler label="尚不知晓">{body}</Spoiler> : body;
}

/** Entries elsewhere that point at this one (lore whose `related` lists it): chips to open them; ones the player doesn't know stay folded. */
export function Backrefs({ id, specs }: { id: string; specs: { collection: string; field: string; label: string }[] }) {
  const m = useModel();
  return <>{specs.map(spec => {
    const coll = rel(spec.collection), all: Record<string, any> = m.value(coll) ?? {};
    if (m.dormant(coll)) return null;
    const hits = Object.keys(all).filter(k => k !== id && Array.isArray(all[k]?.[spec.field]) && all[k][spec.field].includes(id));
    const open = hits.filter(k => m.spoiler([...coll, k]) === 'public'), folded = hits.length - open.length;
    if (!hits.length) return null;
    return (
      <section key={spec.collection} {...solve('backrefs')}>
        <h5 {...part('title')}>{spec.label}<small>{hits.length}</small></h5>
        <div {...part('chips')}>{open.map(k => <RefChip key={k} id={k} />)}{folded ? <span {...part('folded')}>另有 {folded} 条尚不知晓</span> : null}</div>
      </section>
    );
  })}</>;
}

/** Relationship / diplomacy graph between the entities of one collection, collapsed by default. */
function RelationGraph({ item }: { item: any }) {
  const m = useModel(), K = useKit(), go = React.useContext(NavigateContext);
  const path = rel(item.graph), value: Record<string, any> = m.value(path) ?? {};
  const [sel, setSel] = React.useState<string | undefined>();
  const present = new Set<string>(item.present ? m.value(rel(item.present)) ?? [] : []);
  const sizeMeta = item.size ? m.meta([...path, '*', item.size]) : undefined;
  const nodes: GraphNode[] = Object.keys(value).map(id => {
    const tier = sizeMeta?.values ? sizeMeta.values.indexOf(value[id]?.[item.size]) : -1;
    const r = id === m.userId ? 24 : tier >= 0 ? Math.round(22 - tier * 2.5) : 18;
    return { id, label: value[id]?.name ?? id, r, mark: [...(value[id]?.name ?? id)][0], ...(thumbOf(value[id]) ? { image: thumbOf(value[id])! } : {}), kind: id === m.userId ? 'user' : present.has(id) ? 'present' : 'entity' };
  });
  const pairs = new Map<string, { a: string; b: string; weights: number[]; labels: string[]; tones: string[] }>();
  for (const a of Object.keys(value)) for (const [b, r] of Object.entries(value[a]?.[item.edges] ?? {}) as [string, any][]) {
    if (!value[b]) continue;
    const key = a < b ? `${a}|${b}` : `${b}|${a}`;
    const p = pairs.get(key) ?? { a, b, weights: [], labels: [], tones: [] };
    if (item.weight && typeof r?.[item.weight] === 'number') p.weights.push(r[item.weight]);
    // Labels behind a spoiler (how one privately sees the other) stay off the graph.
    const lab = item.label && m.spoiler([...path, a, item.edges, b, item.label]) === 'public' ? r?.[item.label] : undefined;
    const text = Array.isArray(lab) ? lab[0] : lab;
    if (typeof text === 'string' && text && !p.labels.includes(text)) p.labels.push(text);
    if (item.tone && typeof r?.[item.tone] === 'string') p.tones.push(r[item.tone]);
    pairs.set(key, p);
  }
  const edges: GraphEdge[] = [...pairs.values()].map(p => {
    const avg = p.weights.length ? p.weights.reduce((s, w) => s + w, 0) / p.weights.length : 0;
    // Strength of the tie = mean |weight| (love and hatred are both strong ties); the sign only picks the colour.
    const intensity = p.weights.length ? Math.min(1, p.weights.reduce((s, w) => s + Math.abs(w), 0) / p.weights.length / 100) : 0.3;
    const mapped = p.tones.map(t => item.tones?.[t] as Tone | undefined).find(Boolean);
    const tone: Tone = mapped ?? (avg > 15 ? 'positive' : avg < -15 ? 'negative' : 'neutral');
    return { a: p.a, b: p.b, kind: 'relation', tone, label: p.labels.slice(0, 2).join(' / ') || p.tones[0],
      width: 1 + intensity * 5, opacity: 0.4 + intensity * 0.6, length: 220 - intensity * 90, strength: 0.25 + intensity * 0.7 };
  });
  const s = sel ? value[sel] : undefined;
  return (
    <K.CollapseCard title={item.title ?? '关系图'} meta={`${nodes.length} · ${edges.length}`} defaultOpen={!!item.open}>
      {nodes.length < 2 ? <span {...solve('none')}>暂无可显示的关系</span> : (
        <div {...solve('relation-graph')}>
          <GraphView nodes={nodes} edges={edges} selected={sel} onSelect={setSel} label={item.title ?? '关系图'} start={m.userId && value[m.userId] ? m.userId : undefined} height="sm" />
          <div {...part('legend')}>
            {item.legend ? Object.entries(item.legend as Record<string, string>).map(([tone, text]) => <span key={tone} data-tone={tone}><i />{text}</span>) : null}
            <span {...part('hint')}>点节点高亮关系，拖动节点可调整位置</span>
          </div>
          {s ? (
            <div {...part('selected')}>
              <b>{s.name ?? sel}</b>
              {(item.badges ?? []).map((b: string) => s[b] ? <K.Badge key={b} tone="neutral">{String(s[b])}</K.Badge> : null)}
              <K.Button size="sm" variant="ghost" onClick={() => go([...path, sel!])}>{sel === m.userId ? '查看角色' : '查看卡片'}</K.Button>
            </div>
          ) : null}
        </div>
      )}
    </K.CollapseCard>
  );
}

/** Force-directed map: hierarchy (parent) and adjacency (links); detail card for the selected place. */
function MapItem({ item, focus }: { item: any; focus: Focus }) {
  const m = useModel(), K = useKit();
  const path = rel(item.map), places: Record<string, any> = m.value(path) ?? {};
  const here: string | undefined = item.current ? m.value(rel(item.current)) ?? undefined : undefined;
  const parent = item.parent ?? 'parent', links = item.links ?? 'links', hidden = item.discovered ?? 'discovered';
  // The detail card follows the current place until the player picks a node; only a pick highlights.
  const [picked, setPicked] = React.useState<string | undefined>();
  React.useEffect(() => {
    if (focus && focus.path.slice(0, path.length).join('.') === path.join('.') && focus.path[path.length]) setPicked(focus.path[path.length]);
  }, [focus]); // eslint-disable-line react-hooks/exhaustive-deps
  const sel = picked ?? here;
  const known = (id: string) => places[id]?.[hidden] !== false;
  const nameOf = (id: string) => known(id) ? places[id]?.name ?? id : '？？？';
  const parentOf = (id: string): string | undefined => { const p = places[id]?.[parent]; return typeof p === 'string' && places[p] && p !== id ? p : undefined; };
  const childrenOf = (id: string) => Object.keys(places).filter(k => parentOf(k) === id);
  const ancestors = (id: string) => { const out: string[] = []; for (let p = parentOf(id); p && !out.includes(p) && out.length < 32; p = parentOf(p)) out.push(p); return out; };
  // Regions (places with places under them) become areas around their descendants, not nodes.
  const regions = Object.keys(places).filter(id => childrenOf(id).length > 0);
  const leaves = Object.keys(places).filter(id => !regions.includes(id));
  const levelOf = (id: string): number => Math.max(0, ...childrenOf(id).filter(c => regions.includes(c)).map(c => levelOf(c) + 1));
  const groups: GraphGroup[] = regions.map(id => ({
    id, label: nameOf(id), level: levelOf(id),
    members: leaves.filter(l => ancestors(l).includes(id)), current: !!here && (here === id || ancestors(here).includes(id)),
  })).filter(g => g.members.length);
  const nodes: GraphNode[] = Object.keys(places).map(id => {
    const area = groups.some(g => g.id === id);
    const pic = !area && known(id) ? thumbOf(places[id]) : undefined, img = pic ? { image: pic } : {};
    return { id, label: area ? '' : nameOf(id), r: area ? 4 : img.image ? 17 : 14, kind: regions.includes(id) ? 'region' : 'place', current: id === here, muted: !known(id), ...img, ...(area ? { hidden: true } : {}) };
  });
  const edges: GraphEdge[] = [];
  const seen = new Set<string>();
  for (const id of Object.keys(places)) {
    // Invisible springs keep a region's places together.
    const p = parentOf(id);
    if (p) edges.push({ a: id, b: p, kind: 'hierarchy', length: 70, strength: 0.9, hidden: true });
    for (const l of (places[id]?.[links] ?? []) as string[]) {
      const key = id < l ? `${id}|${l}` : `${l}|${id}`;
      // A link from a place to its own region says nothing new on this map.
      if (!places[l] || seen.has(key) || ancestors(id).includes(l) || ancestors(l).includes(id)) continue;
      seen.add(key); edges.push({ a: id, b: l, kind: 'link', ...(regions.includes(id) || regions.includes(l) ? { length: 110, strength: 1.2 } : { length: 150 }) });
    }
  }
  const pickedRegion = sel && groups.find(g => g.id === sel);
  const s = sel ? places[sel] : undefined;
  const [box, wide] = useWide(640);
  return (
    <div ref={box} {...solve('map', { layout: wide ? 'split' : undefined })}>
      <div {...part('view')}>
        <GraphView nodes={nodes} edges={edges} groups={groups} selected={picked} onSelect={setPicked} label={`${m.label(path)}地图`} {...(here ? { start: here } : {})} />
        <div {...part('legend')}><span data-kind="link"><i />相连</span>{groups.length ? <span data-kind="region"><i />区域</span> : null}<span {...part('hint')}>点区域名选中整个区域，拖动区域名可整体移动</span></div>
      </div>
      {s ? (
        <K.Card title={known(sel!) ? s.name ?? sel : '未发现的地点'} meta={<>{s.kind ? <K.Badge tone="neutral">{s.kind}</K.Badge> : null}{sel === here ? <K.Badge tone="accent">当前位置</K.Badge> : null}</>}>
          {known(sel!) && artOf(s) ? <Art key={artOf(s)} src={artOf(s)!} alt={s.name ?? sel!} variant="banner" /> : null}
          {known(sel!) ? <PlaceMusic places={places} id={sel!} parentKey={parent} /> : null}
          <ActionBar path={[...path, sel!]} />
          {known(sel!) ? <EntityBody path={[...path, sel!]} skip={['name', 'kind', hidden]} /> : <p {...solve('paragraph')}>这里还没有被探索。</p>}
          {known(sel!) && item.backrefs ? <Backrefs id={sel!} specs={item.backrefs} /> : null}
          {pickedRegion ? (
            <div {...part('members')}><span {...part('label')}>区域内</span>
              {childrenOf(sel!).map(c => <button key={c} type="button" {...part('member')} data-current={c === here ? '' : undefined} onClick={() => setPicked(c)}>{nameOf(c)}</button>)}
            </div>
          ) : null}
        </K.Card>
      ) : null}
    </div>
  );
}

/** Which music plays at this place: its own track, or the nearest region's. */
function PlaceMusic({ places, id, parentKey }: { places: Record<string, any>; id: string; parentKey: string }) {
  const m = useModel();
  const library = (m.def.bgm?.library ?? []) as { id: string; title?: string }[];
  const field = m.def.bgm?.field ?? 'bgm';
  const seen = new Set<string>();
  for (let cursor: string | undefined = id; cursor && places[cursor] && !seen.has(cursor); cursor = places[cursor]?.[parentKey]) {
    seen.add(cursor);
    const ref = places[cursor]?.[field];
    if (typeof ref !== 'string' || !ref) continue;
    const title = library.find(t => t.id === ref)?.title ?? decodeURIComponent(ref.split('/').pop() ?? ref).replace(/\.[a-z0-9]+$/iu, '');
    return <div {...solve('place-music')}><span aria-hidden="true">♪</span><span>{title}</span>{cursor !== id ? <small>沿用{places[cursor]?.name ?? cursor}的配乐</small> : null}</div>;
  }
  return null;
}

/* ───────── background music ───────── */
function SettingsButton({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  return (
    <button type="button" {...solve('settings-trigger', { open: open ? '' : undefined })} aria-pressed={open} aria-label={open ? '返回状态栏' : '设置'} title={open ? '返回状态栏' : '设置'} onClick={onToggle}>
      <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
      </svg>
    </button>
  );
}
function BgmButton({ bgm }: { bgm: BgmView }) {
  const K = useKit();
  return (
    <K.InfoPopover label="背景音乐" trigger={<span {...solve('bgm-trigger', { playing: bgm.playing ? '' : undefined })} aria-label="背景音乐">♪</span>}>
      <div {...solve('bgm')}>
        <div {...part('now')}><span {...part('label')}>正在播放</span><strong>{bgm.enabled && bgm.title ? bgm.title : '—'}</strong><small>{bgm.source}</small></div>
        <div {...part('row')}><span>播放</span><K.Switch checked={bgm.enabled} onCheckedChange={bgm.onToggle} aria-label="播放背景音乐" /></div>
        <div {...part('row')}><span>音量</span><K.Slider value={Math.round(bgm.volume * 100)} min={0} max={100} onValueChange={v => bgm.onVolume(v / 100)} format={v => v + '%'} aria-label="音量" /></div>
      </div>
    </K.InfoPopover>
  );
}
export { StatusModel, RefChip };
export type { SettingsHost, LocalPrefs } from './settings.js';
